"""Assemble primitives, symbols and texts into the competition JSON."""
import os
import re
import math
import numpy as np
import cv2
from scipy.optimize import linear_sum_assignment

from .textclass import is_desig, prefix_type, desig_prefix, is_gnd_name, is_power_name, is_value
from .text import redecode
from .wiregraph import UF, decompose_edges

UPPER_DIGITS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'


def box_gap(a, b):
    """Gap between two boxes [x0,y0,x1,y1] (0 when overlapping)."""
    dx = max(a[0] - b[2], b[0] - a[2], 0)
    dy = max(a[1] - b[3], b[1] - a[3], 0)
    return math.hypot(dx, dy)


_KNOWN_LONG_PREFIX = {'LED', 'USB', 'BAT', 'ANT', 'ESD', 'MIC', 'KEY', 'BTN', 'LCD', 'SIM', 'PWR', 'RLY', 'TVS', 'NTC', 'PTC',
                      'OLED', 'XTAL', 'BUZ', 'CON', 'SPK', 'MOT', 'FPC', 'HDR', 'DCDC', 'LDO', 'OSC', 'IND', 'SWD', 'TFT',
                      'ADC', 'DAC', 'MCU', 'CAN', 'ETH', 'RJ', 'SD', 'TF', 'IR', 'HDMI', 'POW', 'RST', 'BOOT', 'JTAG'}


def desig_implausibility(t):
    """Part numbers that happen to look like designators (GTX312L, AMS1117) are penalised."""
    m = re.match(r'^([A-Z]+)(\d+)([A-Z]?)', t or '')
    if not m:
        return 0.0
    pre, num, tail = m.groups()
    pen = 0.0
    if tail and len(num) >= 2:
        pen += 0.8
    if len(pre) >= 3 and not any(pre.startswith(k) for k in _KNOWN_LONG_PREFIX):
        pen += 0.6
    if len(num) >= 4:
        pen += 0.6
    return pen


def _ext_bbox(c):
    xs = [c.bbox[0], c.bbox[2]] + [pn.tip[0] for pn in c.pins]
    ys = [c.bbox[1], c.bbox[3]] + [pn.tip[1] for pn in c.pins]
    return [min(xs), min(ys), max(xs), max(ys)]


def tbox(it):
    return [it.x0, it.y0, it.x1, it.y1]


class Comp:
    def __init__(self, gid, bbox, pins):
        self.gids = [gid]
        self.bbox = list(bbox)
        self.pins = list(pins)
        self.type = None
        self.key = None
        self.name = None
        self.value = None
        self.desig_item = None
        self.label_item = None
        self.anon = False

    def __repr__(self):
        return f"Comp({self.key},{self.type},{self.bbox},{len(self.pins)}p)"


def group_body_info(S, P):
    """Per-group body geometry features."""
    glab = S['glab']
    info = {}
    for gid, g in S['groups'].items():
        x0, y0, x1, y1 = g['bbox']
        sub = (glab[y0:y1 + 1, x0:x1 + 1] == gid)
        info[gid] = {'mask': sub, 'off': (x0, y0)}
    return info


def rect_hole(gid, S, P):
    """Largest rectangular hole of a body group (IC body outline), image coords."""
    g = S['groups'][gid]
    if 'rect' in g:
        return g['rect']
    x0, y0, x1, y1 = g['bbox']
    m = (S['glab'][y0:y1 + 1, x0:x1 + 1] == gid).astype(np.uint8)
    cnts, hier = cv2.findContours(m, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
    best = None
    holes = []
    if hier is not None:
        for c, hh in zip(cnts, hier[0]):
            if hh[3] < 0:
                continue
            a = cv2.contourArea(c)
            bx, by, bw, bh = cv2.boundingRect(c)
            if a < 0.8 * bw * bh:
                continue
            rb = [x0 + bx, y0 + by, x0 + bx + bw - 1, y0 + by + bh - 1]
            if min(bw, bh) >= 0.3 * P.u:
                holes.append(rb)
            if bw < 0.9 * P.u or bh < 0.9 * P.u:
                continue
            if best is None or a > best[0]:
                best = (a, rb)
    if best is not None and RECT_COMPARTMENTS and len(holes) > 1:
        # an IC body split into compartments by divider lines (connector banks, 'BANK 1'):
        # the outline is the union of the stacked / side-by-side compartments
        U = list(best[1])
        tol = 2 * P.t + 3
        grown = True
        while grown:
            grown = False
            for h in holes:
                if h[0] >= U[0] and h[1] >= U[1] and h[2] <= U[2] and h[3] <= U[3]:
                    continue
                same_x = abs(h[0] - U[0]) <= tol and abs(h[2] - U[2]) <= tol
                same_y = abs(h[1] - U[1]) <= tol and abs(h[3] - U[3]) <= tol
                if same_x and (0 <= h[1] - U[3] <= tol or 0 <= U[1] - h[3] <= tol):
                    U = [min(U[0], h[0]), min(U[1], h[1]), max(U[2], h[2]), max(U[3], h[3])]
                    grown = True
                elif same_y and (0 <= h[0] - U[2] <= tol or 0 <= U[0] - h[2] <= tol):
                    U = [min(U[0], h[0]), min(U[1], h[1]), max(U[2], h[2]), max(U[3], h[3])]
                    grown = True
        best = (best[0], U)
    g['rect'] = best[1] if best else None
    return g['rect']


RECT_COMPARTMENTS = os.environ.get('PCB_RECT_COMP', '1') == '1'


def clean_pins(S, P):
    u = P.u
    t = P.t
    markers = list(P.gray_dots) + list(getattr(P, 'noconn', []))
    for gid, g in S['groups'].items():
        x0, y0, x1, y1 = g['bbox']
        keep = []
        rect = None
        rect0 = rect_hole(gid, S, P)
        bx0, by0, bx1, by1 = rect0 if rect0 else (x0, y0, x1, y1)
        for pn in g['pins']:
            if pn.kind == 'free':
                tx, ty = pn.tip
                inside = (bx0 - 0.15 * u <= tx <= bx1 + 0.15 * u) and (by0 - 0.15 * u <= ty <= by1 + 0.15 * u)
                if inside or pn.length < 0.45 * u:
                    pn.group = -1
                    continue
                marked = any(math.hypot(mx - tx, my - ty) <= 1.8 * t + 2 for mx, my in markers)
                if not marked:
                    if rect is None:
                        rect = rect_hole(gid, S, P) or False
                    ok = False
                    if rect:
                        rx0, ry0, rx1, ry1 = rect
                        bx, by = pn.base
                        tol = 1.5 * t + 2
                        if pn.o == 'h' and ry0 - tol <= by <= ry1 + tol and (abs(bx - rx0) <= tol + t or abs(bx - rx1) <= tol + t):
                            ok = True
                        if pn.o == 'v' and rx0 - tol <= bx <= rx1 + tol and (abs(by - ry0) <= tol + t or abs(by - ry1) <= tol + t):
                            ok = True
                    if not ok:
                        pn.group = -1
                        continue
            keep.append(pn)
        g['pins'] = keep
    S['pins'] = [pn for pn in S['pins'] if pn.group != -1 and pn.group in S['groups']]


def shape_features(gid, S, P):
    """Simple shape descriptors of a body group."""
    g = S['groups'][gid]
    glab = S['glab']
    x0, y0, x1, y1 = g['bbox']
    m = (glab[y0:y1 + 1, x0:x1 + 1] == gid).astype(np.uint8)
    h, w = m.shape
    f = {'w': w, 'h': h, 'area': int(m.sum())}
    # closed contours (holes)
    cnts, hier = cv2.findContours(m.copy(), cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
    holes = []
    if hier is not None:
        for c, hh in zip(cnts, hier[0]):
            if hh[3] >= 0:
                a = cv2.contourArea(c)
                if a > (1.2 * P.t) ** 2:
                    bx, by, bw, bh = cv2.boundingRect(c)
                    rect = a / max(bw * bh, 1)
                    holes.append((a, bw, bh, rect))
    f['holes'] = holes
    f['fill'] = m.sum() / max(w * h, 1)
    return f


_P_CTX = [None]
SPLIT_FLAG_STACKS = True
ORPHAN_DESIG = True
MERGE_CONTACT_ORPHANS = True
MERGE_HOST_TYPES = ('mosfet', 'bjt', 'box', 'switch', 'amp', 'transfomer', 'crystal')


DESIG_CONSIST = os.environ.get('PCB_DESIG_CONSIST', '1') == '1'
HIDDEN_GND_NONE = os.environ.get('PCB_GND_NONE', '0') == '1'   # public GT: hidden ground name -> 'GND'


def _desig_consistency(C, r, cidx, items, comps, u, w=0.5, cap=1.0):
    """Second pass of the designator assignment.  On one sheet, small parts of one kind and
    orientation carry their designator at the same place (e.g. above-left of every
    horizontal capacitor).  Learn that offset from the unambiguous first-pass pairs and
    penalise assignments that deviate from it: a text between two capacitors goes to the
    one it is 'typically' placed for, not merely the nearer one."""
    nC = len(comps)
    pairs = [(i, j) for i, j in zip(r, cidx) if j < nC and C[i, j] < 1e5]
    if len(pairs) < 3:
        return None

    def grp(i, j):
        c = comps[j]
        pt = prefix_type(items[i].text)
        if len(c.pins) != 2 or pt not in ('r', 'c', 'l', 'd', 'led', 'fuse'):
            return None                    # two-pin passives only: IC labels vary with body size
        o = 'h' if c.feat['w'] >= c.feat['h'] else 'v'
        return (pt, o)

    def off(i, j):
        c = comps[j]
        cx, cy = (c.bbox[0] + c.bbox[2]) / 2.0, (c.bbox[1] + c.bbox[3]) / 2.0
        return np.array([(items[i].cx - cx) / u, (items[i].cy - cy) / u])
    samples = {}
    for i, j in pairs:
        g = grp(i, j)
        if g is None:
            continue
        row = np.sort(C[i, :nC]); col = np.sort(C[:, j])
        m_row = (row[1] - row[0]) if len(row) > 1 else 9.0
        m_col = (col[1] - col[0]) if len(col) > 1 else 9.0
        if C[i, j] <= row[0] + 1e-9 and C[i, j] <= col[0] + 1e-9 and min(m_row, m_col) >= 0.4:
            samples.setdefault(g, []).append(off(i, j))
    typ = {}
    for g, lst in samples.items():
        if len(lst) < 3:
            continue
        A = np.array(lst)
        med = np.median(A, axis=0)
        spread = float(np.median(np.linalg.norm(A - med, axis=1)))
        if spread <= 0.5:
            typ[g] = med
    if not typ:
        return None
    C2 = C.copy()
    changed = False
    for i in range(C.shape[0]):
        for j in range(nC):
            if C[i, j] >= 1e5:
                continue
            g = grp(i, j)
            if g in typ:
                C2[i, j] += w * min(float(np.linalg.norm(off(i, j) - typ[g])), cap)
                changed = True
    return C2 if changed else None


MERGE_SWITCH_PIECES = os.environ.get('PCB_SW_MERGE', '1') == '1'


def _merge_switch_pieces(comps, u):
    """Tactile switches are drawn as two separate pin-to-pin bars plus the lever: only the
    piece next to the designator gets it, the other bar (with its two pins) would be dropped.
    Fold an undesignated piece lying parallel to the switch (overlapping along the bars,
    within ~2.6u across) into it."""
    hosts = [c for c in comps.values() if c.type == 'switch' and c.key and len(c.pins) < 4]
    free = [c for c in comps.values() if c.type is None and c.key is None and not c.anon and c.pins
            and not getattr(c, 'flag', False) and len(c.pins) <= 3]
    for c in hosts:
        for p in list(free):
            if len(c.pins) + len(p.pins) > 4:
                continue
            ox = min(c.bbox[2], p.bbox[2]) - max(c.bbox[0], p.bbox[0])
            oy = min(c.bbox[3], p.bbox[3]) - max(c.bbox[1], p.bbox[1])
            wmin = max(1.0, min(c.bbox[2] - c.bbox[0], p.bbox[2] - p.bbox[0]))
            hmin = max(1.0, min(c.bbox[3] - c.bbox[1], p.bbox[3] - p.bbox[1]))
            gx = max(0.0, max(c.bbox[0], p.bbox[0]) - min(c.bbox[2], p.bbox[2]))
            gy = max(0.0, max(c.bbox[1], p.bbox[1]) - min(c.bbox[3], p.bbox[3]))
            if (ox >= 0.6 * wmin and gy <= 2.6 * u) or (oy >= 0.6 * hmin and gx <= 2.6 * u):
                c.bbox = [min(c.bbox[0], p.bbox[0]), min(c.bbox[1], p.bbox[1]),
                          max(c.bbox[2], p.bbox[2]), max(c.bbox[3], p.bbox[3])]
                c.gids = c.gids + p.gids
                c.pins = c.pins + p.pins
                p.pins = []
                p.type = None
                p.key = None
                free.remove(p)
                c.sw_merged = True


MERGE_TOUCHING = os.environ.get('PCB_MERGE_TOUCH', '1') == '1'


def _merge_touching_pieces(comps, S, P):
    """A transistor's body diode drawn as a separate stroke group often takes the
    designator (it is the piece nearest to the text) while the transistor itself - gate,
    channel, the three real pins - stays undesignated and would be dropped.  The diode's
    'pins' end ON the transistor's drain / source lines: fold the undesignated piece they
    touch into the designated one and drop those internal joints."""
    glab = S['glab']
    H, W = glab.shape
    r = int(P.t + 2)
    gid2c = {}
    for c in comps.values():
        for g in c.gids:
            gid2c[g] = c

    def touching(pn, gids):
        x, y = int(round(pn.tip[0])), int(round(pn.tip[1]))
        win = glab[max(0, y - r):min(H, y + r + 1), max(0, x - r):min(W, x + r + 1)]
        return set(int(v) for v in np.unique(win)) & set(gids)
    for c in list(comps.values()):
        if c.key is None or c.anon or (c.type or prefix_type(c.key)) not in ('mosfet', 'bjt'):
            continue
        cand = {}
        for pn in c.pins:
            x, y = int(round(pn.tip[0])), int(round(pn.tip[1]))
            win = glab[max(0, y - r):min(H, y + r + 1), max(0, x - r):min(W, x + r + 1)]
            for g in np.unique(win):
                g = int(g)
                o = gid2c.get(g)
                if g <= 0 or g in c.gids or o is None or o is c:
                    continue
                if o.type is not None or o.key is not None or o.anon or getattr(o, 'flag', False) or not o.pins:
                    continue
                cand.setdefault(id(o), [o, 0])[1] += 1
        for o, k in cand.values():
            if k < 1 or len(o.pins) + len(c.pins) > 8:
                continue
            keep = [pn for pn in c.pins if not touching(pn, o.gids)] + [pn for pn in o.pins if not touching(pn, c.gids)]
            if len(keep) < 2:
                continue
            c.bbox = [min(c.bbox[0], o.bbox[0]), min(c.bbox[1], o.bbox[1]), max(c.bbox[2], o.bbox[2]), max(c.bbox[3], o.bbox[3])]
            c.gids = c.gids + o.gids
            for g in o.gids:
                gid2c[g] = c
            c.pins = keep
            o.pins = []
            o.type = None
            o.key = None
            if c.type is not None:
                c.type = 'bjt' if _n_diagonals(c, S, P) >= 2 and not _has_gate_gap(c, S, P) else 'mosfet'


def _merge_orphan_pieces(comps):
    """A symbol cut into pieces at internal joints (MOSFET + body diode, multi-part outlines):
    the pieces are tied together by mated 'contact' pins.  Pieces without a designator (they
    would be dropped) are folded into the one designated part they are tied to."""
    owner = {}
    for key, c in comps.items():
        for pn in c.pins:
            owner[id(pn)] = key
    parent = {k: k for k in comps}
    P = _P_CTX[0]
    dots = getattr(P, 'contact_dots', []) if P is not None else []
    tol = (1.5 * P.t + 3) if P is not None else 6

    def dotted(pn):                         # a real pin-to-pin connection carries a green dot
        return any(abs(x - pn.tip[0]) <= tol and abs(y - pn.tip[1]) <= tol for x, y, _ in dots)

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a
    for key, c in comps.items():
        if c.anon or getattr(c, 'flag', False):
            continue
        for pn in c.pins:
            m = getattr(pn, 'mate', None)
            if m is None or id(m) not in owner:
                continue
            k2 = owner[id(m)]
            o = comps[k2]
            if o.anon or getattr(o, 'flag', False) or k2 == key:
                continue
            if ((c.type is None) or (o.type is None)) and not dotted(pn):   # internal joints only
                parent[find(key)] = find(k2)
    groups = {}
    for k in comps:
        groups.setdefault(find(k), []).append(k)
    for members in groups.values():
        if len(members) < 2:
            continue
        named = [k for k in members if comps[k].type is not None]
        if len(named) != 1 or not str(comps[named[0]].type).startswith(MERGE_HOST_TYPES):
            continue
        host = comps[named[0]]
        inside = set(members)
        pieces = [comps[k] for k in members if k != named[0]]
        allpins = host.pins + [pn for pc in pieces for pn in pc.pins]
        keep = []
        for pn in allpins:
            m = getattr(pn, 'mate', None)
            if m is not None and owner.get(id(m)) in inside:
                continue                    # internal joint of the symbol
            keep.append(pn)
        for pc in pieces:
            host.bbox = [min(host.bbox[0], pc.bbox[0]), min(host.bbox[1], pc.bbox[1]),
                         max(host.bbox[2], pc.bbox[2]), max(host.bbox[3], pc.bbox[3])]
            host.gids = host.gids + pc.gids
            pc.type = None
            pc.key = None
            pc.pins = []
        host.pins = keep
_ORPHAN_RE = re.compile(r'^[A-Za-z\u4e00-\u9fff][A-Za-z_\u4e00-\u9fff+\-]*\d{0,3}$')
_CJK = re.compile(r'[\u4e00-\u9fff]')


def drop_red_text_parts(comps, texts, P):
    """Free annotations written in the symbol colour (red Chinese notes, formulas) form red
    'bodies'; one touching a wire gets a pin and would become a net label.  Drop small
    one-pin parts mostly covered by confidently read red text."""
    u = P.u
    reds = [it for it in texts if it.color == 'red' and it.text and it.conf >= 0.8
            and (_CJK.search(it.text) or sum(ch.isalnum() for ch in it.text) >= 3)]
    if not reds:
        return comps
    out = {}
    for key, c in comps.items():
        x0, y0, x1, y1 = c.bbox
        w, h = x1 - x0 + 1, y1 - y0 + 1
        if len(c.pins) <= 1 and min(w, h) <= 0.9 * u:
            cov = cjk = 0.0
            for it in reds:
                ix = min(x1, it.x1) - max(x0, it.x0) + 1
                iy = min(y1, it.y1) - max(y0, it.y0) + 1
                if ix > 0 and iy > 0:
                    cov += ix * iy
                    if _CJK.search(it.text):
                        cjk += ix * iy
            if cov >= 0.4 * w * h or cjk >= 0.15 * w * h:   # Chinese glyphs are never symbol graphics
                continue
        out[key] = c
    return out


def split_flag_stacks(comps, S, P, blue):
    """Net-port flags stacked edge to edge (a column of hexagons, one per signal) merge into
    one body group.  Recognise the stack - k parallel pins on one side at a regular pitch,
    k closed cells, a label beyond the far end of every cell - and split it into k flags."""
    u, t = P.u, P.t
    out = {}
    for key, c in comps.items():
        k = len(c.pins)
        if k < 2 or len(c.gids) != 1:
            out[key] = c
            continue
        os_ = {pn.o for pn in c.pins}
        if len(os_) != 1 or os_ & {'z'}:
            out[key] = c
            continue
        o = os_.pop()
        x0, y0, x1, y1 = c.bbox
        if o == 'h':
            along0, along1 = x0, x1
            tips_a = [pn.tip[0] for pn in c.pins]
            cross = sorted(pn.tip[1] for pn in c.pins)
            c0, c1 = y0, y1
        else:
            along0, along1 = y0, y1
            tips_a = [pn.tip[1] for pn in c.pins]
            cross = sorted(pn.tip[0] for pn in c.pins)
            c0, c1 = x0, x1
        L = along1 - along0
        mid = (along0 + along1) / 2
        side = [ta < mid for ta in tips_a]
        if not (all(side) or not any(side)) or max(tips_a) - min(tips_a) > 2 * t + 2:
            out[key] = c
            continue
        if not (1.2 * u <= L <= 8 * u):
            out[key] = c
            continue
        gaps = np.diff(cross)
        if gaps.min() < 0.6 * u or gaps.max() > 1.25 * gaps.min():
            out[key] = c
            continue
        pitch = float(np.median(gaps))
        if (c1 - c0) > k * pitch + 0.6 * pitch:
            out[key] = c
            continue
        holes = [hh for hh in c.feat['holes'] if hh[0] > 0.15 * pitch * L]
        if len(holes) < k:
            out[key] = c
            continue
        # a label beyond the far end, aligned with each pin
        far_lo = all(side)              # pins on the low side -> labels beyond along1
        hits = 0
        for cc in cross:
            for it in blue:
                ic = it.cy if o == 'h' else it.cx
                if abs(ic - cc) > 0.35 * pitch:
                    continue
                if o == 'h':
                    gap = it.x0 - x1 if far_lo else x0 - it.x1
                else:
                    gap = it.y0 - y1 if far_lo else y0 - it.y1
                if -0.2 * u <= gap <= 1.0 * u:
                    hits += 1
                    break
        if hits < max(2, k - 1):
            out[key] = c
            continue
        gid = c.gids[0]
        gx0, gy0, gx1, gy1 = S['groups'][gid]['bbox']
        m = (S['glab'][gy0:gy1 + 1, gx0:gx1 + 1] == gid)
        pins = sorted(c.pins, key=lambda pn: pn.tip[1] if o == 'h' else pn.tip[0])
        for i, pn in enumerate(pins):
            cc = pn.tip[1] if o == 'h' else pn.tip[0]
            lo, hi = cc - pitch / 2, cc + pitch / 2
            if o == 'h':
                rows = m[max(int(np.ceil(lo)) - gy0, 0):max(int(np.floor(hi)) - gy0 + 1, 0)]
                ys, xs = np.nonzero(rows)
                if len(xs) == 0:
                    continue
                bb = [gx0 + xs.min(), max(int(np.ceil(lo)), gy0) + ys.min(), gx0 + xs.max(), max(int(np.ceil(lo)), gy0) + ys.max()]
            else:
                cols = m[:, max(int(np.ceil(lo)) - gx0, 0):max(int(np.floor(hi)) - gx0 + 1, 0)]
                ys, xs = np.nonzero(cols)
                if len(xs) == 0:
                    continue
                bb = [max(int(np.ceil(lo)), gx0) + xs.min(), gy0 + ys.min(), max(int(np.ceil(lo)), gx0) + xs.max(), gy0 + ys.max()]
            nc = Comp(gid, bb, [pn])
            nc.feat = c.feat
            nc.forced_flag = True
            nc.split_from = key
            out[(key, i)] = nc
    return out


CARVE_FLAGS = os.environ.get('PCB_CARVE_FLAGS', '1') == '1'


def carve_attached_flags(comps, S, P, blue):
    """Net-port flags drawn touching a connector's pin ends (no wire in between) become part
    of the connector's stroke group.  Find them as arrow-shaped closed cells outside the IC
    rectangle with a label beyond their far end, cut each out as a one-pin flag and give the
    host a pin at the contact point."""
    from .sym import Pin
    u, t = P.u, P.t
    out = dict(comps)
    for key, c in comps.items():
        if len(c.gids) != 1 or c.pins and len(c.pins) == 1:
            continue
        gid = c.gids[0]
        rect = rect_hole(gid, S, P)
        if not rect:
            continue
        gx0, gy0, gx1, gy1 = S['groups'][gid]['bbox']
        m = (S['glab'][gy0:gy1 + 1, gx0:gx1 + 1] == gid).astype(np.uint8)
        cnts, hier = cv2.findContours(m, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
        if hier is None:
            continue
        k = 0
        for cnt, hh in zip(cnts, hier[0]):
            if hh[3] < 0:
                continue
            bx, by, bw, bh = cv2.boundingRect(cnt)
            hx0, hy0, hx1, hy1 = gx0 + bx, gy0 + by, gx0 + bx + bw - 1, gy0 + by + bh - 1
            if not (hx1 < rect[0] - t or hx0 > rect[2] + t or hy1 < rect[1] - t or hy0 > rect[3] + t):
                continue                        # inside / overlapping the IC body
            long_, short = max(bw, bh), min(bw, bh)
            if not (0.35 * u <= short <= 1.2 * u and 1.8 <= long_ / max(short, 1) <= 6 and long_ <= 5 * u):
                continue
            fill = cv2.contourArea(cnt) / max(bw * bh, 1)
            if not (0.55 <= fill <= 0.92):
                continue
            horiz = bw >= bh
            cc = (hy0 + hy1) / 2 if horiz else (hx0 + hx1) / 2
            # label beyond one end, aligned with the axis; the contact is the other end
            lab = None
            for it in blue:
                ic = it.cy if horiz else it.cx
                if abs(ic - cc) > max(0.45 * short, 0.3 * u):
                    continue
                if horiz:
                    g_lo, g_hi = hx0 - it.x1, it.x0 - hx1
                else:
                    g_lo, g_hi = hy0 - it.y1, it.y0 - hy1
                for side, gg in (('lo', g_lo), ('hi', g_hi)):
                    if -0.2 * u <= gg <= 1.6 * u and (lab is None or gg < lab[0]):
                        lab = (gg, side)
            if lab is None:
                continue
            e = t                               # hole = inner edge; graphics bbox = outer edge
            bb = [hx0 - e, hy0 - e, hx1 + e, hy1 + e]
            if horiz:
                tipx = bb[2] if lab[1] == 'lo' else bb[0]
                tip, base, o = (tipx, cc), (tipx - (1 if lab[1] == 'lo' else -1) * 0.3 * u, cc), 'h'
            else:
                tipy = bb[3] if lab[1] == 'lo' else bb[1]
                tip, base, o = (cc, tipy), (cc, tipy - (1 if lab[1] == 'lo' else -1) * 0.3 * u), 'v'
            pn = Pin(tip, base, o, 'contact')
            pn.group = gid
            nc = Comp(gid, bb, [pn])
            nc.feat = {'w': bb[2] - bb[0], 'h': bb[3] - bb[1], 'area': int(cv2.contourArea(cnt)),
                       'holes': [(cv2.contourArea(cnt), bw, bh, fill)], 'fill': 0.3}
            nc.forced_flag = True
            nc.carved_from = key
            out[(key, 'flag', k)] = nc
            k += 1
            # the host's pin ends at the flag
            if not any(abs(p.tip[0] - tip[0]) + abs(p.tip[1] - tip[1]) <= 2 * t + 2 for p in c.pins):
                if o == 'h':
                    bx_ = rect[0] if tip[0] < rect[0] else rect[2]
                    hp = Pin(tip, (bx_, tip[1]), 'h', 'contact')
                else:
                    by_ = rect[1] if tip[1] < rect[1] else rect[3]
                    hp = Pin(tip, (tip[0], by_), 'v', 'contact')
                hp.group = gid
                c.pins.append(hp)
        if k:
            c.bbox = [min(c.bbox[0], rect[0]), min(c.bbox[1], rect[1]), max(c.bbox[2], rect[2]), max(c.bbox[3], rect[3])]
    return out


def build(P, items, S, lines, uf, terms, lib=None, img_shape=None):
    global _LIB
    _LIB = lib
    _P_CTX[0] = P
    NAME_LOG.clear()
    u, t = P.u, P.t
    H = P.H
    clean_pins(S, P)
    groups = S['groups']
    # ---------------------------------------------------------------- texts
    texts = [it for it in items if it.text]
    from .textfix import resolve_k_case
    _KFIX[0] = resolve_k_case(texts)
    blue = [it for it in texts if it.color == 'blue']
    # ---------------------------------------------------------------- comps from groups
    comps = {}
    for gid, g in groups.items():
        if g['area'] < max(6, 0.6 * t * t):
            continue
        c = Comp(gid, g['bbox'], g['pins'])
        c.feat = shape_features(gid, S, P)
        comps[gid] = c
    comps = drop_red_text_parts(comps, texts, P)
    if SPLIT_FLAG_STACKS:
        comps = split_flag_stacks(comps, S, P, blue)
    if CARVE_FLAGS:
        comps = carve_attached_flags(comps, S, P, blue)
    # ---------------------------------------------------------------- power / labels (1-pin groups)
    used_text = set()

    def near_texts(c, maxd, pool):
        out = []
        for it in pool:
            d = box_gap(c.bbox, tbox(it))
            if d <= maxd:
                out.append((d, it))
        out.sort(key=lambda x: x[0])
        return out

    one_pin = [c for c in comps.values() if len(c.pins) == 1]
    blacks = [it for it in texts if it.color == 'black']
    for c in one_pin:
        c.flag = getattr(c, 'forced_flag', False) or _is_flag(c, P)
        if c.flag:
            # a box with a pin number written inside is a one-pin connector (H2 '1'), not a net flag
            x0, y0, x1, y1 = c.bbox
            if any(it.text.isdigit() and x0 < it.cx < x1 and y0 < it.cy < y1 for it in blacks):
                c.flag = False
    # net labels (flag shaped ports): text next to the flag
    for c in one_pin:
        if not c.flag:
            continue
        cand = [(d + _side_pen(c, it, u) + _align_pen(c, it, u), it) for d, it in near_texts(c, 1.5 * u, blue)
                if it.id not in used_text and not is_value(it.text)]
        cand.sort(key=lambda x: x[0])
        if cand:
            d, it = cand[0]
            c.type = 'net_bidirection'
            c.label_item = it
            c.key = it.text
            c.value = it.text
            c.name = it.text
            used_text.add(it.id)
    # power / ground symbols recognised by SHAPE (T bar / stacked bars); the name text can be anything
    # (VM1, 3V3_MCU, VBAT ...), so it is taken from the far side of the symbol, not matched by a regex
    for c in one_pin:
        if c.flag or c.type is not None:
            continue
        ps = _power_shape(c, S, P)
        if ps is None:
            continue
        tip = np.array(c.pins[0].tip, float)
        ctr = np.array([(c.bbox[0] + c.bbox[2]) / 2.0, (c.bbox[1] + c.bbox[3]) / 2.0])
        axis = ctr - tip
        nrm = np.linalg.norm(axis)
        axis = axis / nrm if nrm > 1e-6 else np.array([0.0, -1.0])
        best = None
        for d, it in near_texts(c, 1.3 * u, blue):
            if it.id in used_text or is_value(it.text):
                continue
            if ps == 'gnd' and not (is_gnd_name(it.text) or is_power_name(it.text)):
                continue
            if ps == 'v' and not is_power_name(it.text) and is_desig(it.text) and prefix_type(it.text) not in (None,):
                continue
            tc = np.array([it.cx, it.cy]) - ctr
            along = float(tc @ axis)
            beside = 0.0
            if along < -0.2 * u:
                # text on the pin side belongs to something else - unless it sits beside the
                # stem (between the pin tip and the bars), a common place for 'PGND' / 'AGND'
                if along < -nrm - 0.1 * u or not (is_gnd_name(it.text) if ps == 'gnd' else is_power_name(it.text)):
                    continue
                beside = 0.3 * u
            score = d + beside - 0.3 * u * (1 if is_power_name(it.text) else 0)
            if best is None or score < best[0]:
                best = (score, it)
        if ps == 'v' and best is None:
            continue                        # a lone bar without a name: leave it to the generic logic
        c.type = 'gnd' if (ps == 'gnd' or (best is not None and is_gnd_name(best[1].text))) else 'v'
        if best is not None:
            it = best[1]
            c.label_item = it
            used_text.add(it.id)
            c.value = 'GND' if (c.type == 'gnd' and len(it.text) == 3 and it.text != 'GND' and not it.text.endswith('GND')) else _fix_comma_only(it)
        else:
            c.value = None if HIDDEN_GND_NONE else 'GND'     # name not printed: value None (official labels)
        c.anon = True
    # power / ground symbols with a name text
    for c in one_pin:
        if c.flag or c.type is not None:
            continue
        cand = near_texts(c, 1.2 * u, blue)
        pw = [(d + _side_pen(c, it, u), it) for d, it in cand if is_power_name(it.text) and not is_desig(it.text) and it.id not in used_text]
        pw.sort(key=lambda x: x[0])
        if pw:
            d, it = pw[0]
            c.label_item = it
            used_text.add(it.id)
            c.type = 'gnd' if is_gnd_name(it.text) else 'v'
            c.value = 'GND' if (c.type == 'gnd' and len(it.text) == 3 and it.text != 'GND' and not it.text.endswith('GND')) else _fix_comma_only(it)
            c.anon = True
    # ---------------------------------------------------------------- designators
    desig_items = [it for it in blue if it.id not in used_text and _fix_desig(it)
                   and not (lib is not None and len(it.text) >= 5 and lib.match_name(it.text, 0.0))]
    cand_comps = [c for c in comps.values() if not c.anon and c.type is None]
    if desig_items and cand_comps:
        C = np.full((len(desig_items), len(cand_comps)), 1e6)
        onw = [_on_wire(it, P) for it in desig_items]
        rects = {id(c): rect_hole(c.gids[0], S, P) for c in cand_comps}
        for i, it in enumerate(desig_items):
            for j, c in enumerate(cand_comps):
                d = box_gap(c.bbox, tbox(it)) / u
                if d > 3.0:
                    # labels of big ICs sit beyond the pin row: measure from the pin tips too
                    d2 = box_gap(_ext_bbox(c), tbox(it)) / u
                    if d2 > 2.6 or len(c.pins) < 8:
                        continue
                    d = 0.4 + 0.8 * d2    # must stay below the 2.6 cost of leaving the text unassigned
                pt = prefix_type(it.text)
                npins = len(c.pins)
                pen = 0.8 if onw[i] else 0.0
                big = rects[id(c)] is not None and min(c.feat['w'], c.feat['h']) >= 2.0 * u
                if pt == 'box' and not big and max(c.feat['w'], c.feat['h']) < 1.6 * u and npins <= 2:
                    pen += 0.8
                if pt in ('r', 'c', 'l', 'd', 'led') and big and npins >= 3:
                    pen += 1.5
                if big and npins >= 4 and pt not in ('box', 'switch', 'pin', None):
                    pen += 0.8
                if npins == 0:
                    pen += 1.5
                if pt in ('r', 'c', 'l') and npins > 2:
                    pen += 1.0
                elif pt == 'battary' and npins > 3:
                    pen += 2.0            # a 4-pin 'BAT0': a net label next to a transistor
                if (pt == 'box' and npins < 2 and c.feat['w'] < 1.5 * u and c.feat['h'] < 1.5 * u
                        and not max(c.feat['w'], c.feat['h']) < 1.6 * u):      # never stack the two small-box penalties
                    pen += 0.8
                if npins == 1 and pt in ('r', 'c', 'l', 'd', 'led'):
                    pen += 0.6
                C[i, j] = d + pen + desig_implausibility(it.text)
        # dummy columns: leaving a text unassigned costs a fixed amount
        nT, nC = C.shape
        C = np.hstack([C, np.full((nT, nT), 2.6)])
        r, cidx = linear_sum_assignment(C)
        if DESIG_CONSIST:
            C2 = _desig_consistency(C, r, cidx, desig_items, cand_comps, u)
            if C2 is not None:
                r, cidx = linear_sum_assignment(C2)
        for i, j in zip(r, cidx):
            if j < nC and C[i, j] < 1e5:
                c = cand_comps[j]
                c.desig_item = desig_items[i]
                c.key = desig_items[i].text
                used_text.add(desig_items[i].id)
    # components that got no designator would be dropped altogether: give multi-pin ones the
    # nearest free label outside their body (non-standard designators: SWD, BUZZER1, SERVO_A)
    if MERGE_TOUCHING:
        _merge_touching_pieces(comps, S, P)
        one_pin = [c for c in one_pin if len(c.pins) == 1]
    if ORPHAN_DESIG:
        for c in comps.values():
            if c.anon or c.type is not None or c.key is not None or len(c.pins) < 3:
                continue
            eb = _ext_bbox(c)
            best = None
            for it in blue:
                t = it.text
                if it.id in used_text or not t or len(t) > 12 or is_value(t) or is_power_name(t):
                    continue
                if not _ORPHAN_RE.match(t):     # designator-shaped: letters, then at most 3 digits (not a part number)
                    continue
                if c.bbox[0] < it.cx < c.bbox[2] and c.bbox[1] < it.cy < c.bbox[3]:
                    continue
                if _on_wire(it, P):
                    continue
                d = box_gap(eb, tbox(it)) / u
                if d <= 1.5 and (best is None or d < best[0]):
                    best = (d, it)
            if best is not None:
                c.desig_item = best[1]
                c.key = best[1].text
                c.orphan_key = True
                used_text.add(best[1].id)
    # GND symbols without text: detect by shape (parallel bars)
    for c in one_pin:
        if c.type is None and c.key is None:
            ps = _power_shape(c, S, P)
            if ps:                          # nameless bars are filtered by size at the end
                c.type = ps
                c.value = 'GND' if (ps == 'gnd' and not HIDDEN_GND_NONE) else None
                c.anon = True
    # ---------------------------------------------------------------- net labels (1-pin, text along axis)
    for c in one_pin:
        if c.type is not None or c.key is not None:
            continue
        cand = [(d, it) for d, it in near_texts(c, 1.0 * u, blue) if it.id not in used_text and not is_value(it.text)]
        if cand:
            d, it = cand[0]
            c.type = 'net_bidirection'
            c.label_item = it
            c.key = it.text
            c.value = it.text
            c.name = it.text
            used_text.add(it.id)
    # ---------------------------------------------------------------- types
    for c in comps.values():
        if c.type is not None:
            continue
        if c.key:
            pt = prefix_type(c.key) or 'box'
            if getattr(c, 'orphan_key', False) and not is_desig(c.key) and pt not in ('buzzer', 'battary', 'led'):
                pt = 'box'                  # SWD / SERVO_A: a connector, not a switch
            if pt == 'd' and _has_arrows(c, S, P):
                pt = 'led'
            if pt == 'box' and len(c.pins) == 1 and re.match(r'^(H|J|P|CN|JP|TP|PIN|PAD)\d', c.key or ''):
                pt = 'pin'                  # one-pin headers / pads; a one-pin U stays an IC (box)
            npin = len(c.pins)
            if pt in ('mosfet', 'bjt'):
                pt = 'bjt' if _n_diagonals(c, S, P) >= 2 and not _has_gate_gap(c, S, P) else 'mosfet'
            elif pt == 'crystal_2pin':
                pt = {3: 'crystal_3pin', 4: 'crystal_4pin'}.get(npin, 'crystal_2pin') if npin <= 4 else 'box'
            elif pt == 'box' and npin >= 3 and not rect_hole(c.gids[0], S, P) and (
                    _amp_triangle(c, S, P) if AMP_TRIANGLE else _n_diagonals(c, S, P) >= 2):
                pt = {3: 'amp_3pin', 5: 'amp_5pin', 7: 'amp_7pin'}.get(npin, 'amp')
            c.type = pt
    # drop unassigned comps without pins/type
    if MERGE_CONTACT_ORPHANS:
        _merge_orphan_pieces(comps)
    if MERGE_SWITCH_PIECES:
        _merge_switch_pieces(comps, u)

    final = [c for c in comps.values() if c.type is not None]
    final = _merge_contact_pieces(final, used_text)
    # ---------------------------------------------------------------- values / names
    free_blue = [it for it in blue if it.id not in used_text]
    # values of passives: one-to-one assignment
    passives = [c for c in final if c.desig_item is not None and c.type in ('r', 'c', 'l', 'fuse', 'crystal_2pin')]
    vcands = [it for it in free_blue if not is_desig(it.text) and not is_power_name(it.text)
              and (len(it.text) <= 14 or (len(it.text) <= 22 and re.search(r'[,%\s±]', it.text)))]
    if passives and vcands:
        C = np.full((len(passives), len(vcands)), 1e6)
        for i, c in enumerate(passives):
            for j, it in enumerate(vcands):
                d = min(box_gap(tbox(it), tbox(c.desig_item)), box_gap(tbox(it), c.bbox) + 0.3 * u) / u
                if not is_value(it.text):
                    d += 0.9
                d += _unit_pen(it.text, c.type)
                if d <= 2.2:
                    C[i, j] = d
        r, cc = linear_sum_assignment(C)
        for i, j in zip(r, cc):
            if C[i, j] < 1e5:
                passives[i].value = _fix_value(vcands[j], passives[i].type)
                used_text.add(vcands[j].id)
    for c in sorted(final, key=lambda c: (c.desig_item is None,)):
        if c.desig_item is None:
            continue
        if c.type in ('r', 'c', 'l', 'fuse', 'crystal_2pin'):
            pass
        else:
            res = pick_name(c, free_blue, used_text, u, lib if c.type in ("box", "switch") else None)
            if res:
                c.name = res[0]
                for it in res[1]:
                    used_text.add(it.id)
    # ---------------------------------------------------------------- LED arrows
    reassign_arrows(final, S, P)
    # ---------------------------------------------------------------- contact tips
    fix_contacts(final, P)
    standard_contact_tips(final, S, P)
    # ---------------------------------------------------------------- bbox refinement
    for c in final:
        if c.type in ('led', 'fuse', 'crystal_2pin', 'l', 'switch', 'buzzer', 'battary', 'other'):
            trim_stems(c, S, P)
        refine_bbox(c, P)
        if c.type in ('box', 'switch', 'pin'):
            r = rect_hole(c.gids[0], S, P)
            if r:
                h = P.t * 0.5
                c.bbox = [r[0] - h, r[1] - h, r[2] + h, r[3] + h]
    # ---------------------------------------------------------------- box pins
    for c in final:
        if c.type in ('box', 'switch'):
            assign_box_pins(c, items, P, S, lib)
    # a power port whose name was not read: keep it only with the standard port-bar size
    # (about 1 x 0.6 units); everything else that ends up here is debris
    def _port_sized(c):
        w, h = c.bbox[2] - c.bbox[0], c.bbox[3] - c.bbox[1]
        M, m = max(w, h) / u, min(w, h) / u
        return 0.9 <= M <= 1.25 and 0.45 <= m <= 0.78
    final = [c for c in final if not (c.type == 'v' and not c.value and not _port_sized(c))]
    return final


LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
DIGITS = '0123456789'


def _fix_desig(it):
    s = it.text.replace(' ', '')
    if is_desig(s):
        it.text = s
        return True
    # constrained re-decode
    s2, conf = redecode(it, UPPER_DIGITS)
    if is_desig(s2) and conf > 0.5:
        it.text = s2
        return True
    # designator-shaped text (letters then digits) misread: decode letters/digits split
    if it.probs is not None and 2 <= len(s) <= 6 and s[:1].isalpha() and not it.vert or (it.probs is not None and it.vert and 2 <= len(s) <= 6):
        from .ocr import get_rec
        rec = get_rec()
        best = None
        for k in (1, 2, 3):
            t, c = rec.decode_split(it.probs, LETTERS, DIGITS, k)
            if is_desig(t) and len(t) == len(s) and (best is None or c > best[1]):
                best = (t, c)
        if best and best[1] > 0.4 and best[0][:1] == s[:1].upper():
            it.text = best[0]
            return True
    return False


_KFIX = [None]


def _fix_comma_only(it):
    from .textfix import fix_comma
    return fix_comma(it)


_RATING_SPACE = [re.compile(r'^(\d+(?:\.\d+)?[pnuµμm]?F)(\d+(?:\.\d+)?V)$'),       # 470uF25V -> 470uF 25V
                 re.compile(r'^(\d+(?:\.\d+)?[kKMmR]?Ω?)(\d+(?:\.\d+)?%)$'),        # 10K1%    -> 10K 1%
                 re.compile(r'^(\d+(?:\.\d+)?[pnuµμm]?[FH])(\d+(?:\.\d+)?%)$')]


def _fix_value(it, ctype=None):
    from .textfix import fix_comma, repair_value, fix_trailing_ohm
    t = fix_comma(it).replace(' ', '')
    if ctype == 'r':
        t = fix_trailing_ohm(it, t)
    t = re.sub(r'^(\d+(?:\.\d+)?)rF$', r'\1nF', t)          # 'n' read as 'r'
    t = repair_value(t)
    if _KFIX[0] is not None:
        t = _KFIX[0](it, t)
    for rx in _RATING_SPACE:                                   # value + rating keep their space
        m = rx.match(t)
        if m:
            t = m.group(1) + ' ' + m.group(2)
            break
    return t


def _unit_pen(text, ctype):
    """A capacitance cannot be a resistor's value and so on."""
    t = text.replace(' ', '')
    if re.search(r'\d(?:[pnuµμm])?F', t):
        return 0.0 if ctype == 'c' else 3.0
    if re.search(r'\d(?:[pnuµμm])?H$', t):
        return 0.0 if ctype == 'l' else 3.0
    if 'Ω' in t:
        return 0.0 if ctype == 'r' else 3.0
    return 0.0


def _power_shape(c, S, P):
    """Classify a text-less one-pin symbol: 'gnd' (stacked bars), 'v' (single bar) or None."""
    if len(c.pins) != 1:
        return None
    pn = c.pins[0]
    f = c.feat
    x0, y0, x1, y1 = c.bbox
    rs = [s for s in S['rsegs'] if box_gap(c.bbox, [s.p0()[0], s.p0()[1], s.p1()[0], s.p1()[1]]) <= 1]
    # power symbols are drawn with axis-aligned strokes only; LED arrows and other
    # diagonal debris are not power symbols
    X0, Y0, X1, Y1 = int(x0), int(y0), int(x1), int(y1)
    ink = P.red[Y0:Y1 + 1, X0:X1 + 1] > 0
    if ink.sum() > 0:
        cov = np.zeros_like(ink)
        for s in rs:
            if s.length < 0.35 * P.u and s.t > 1.6 * P.t:   # arrow heads: short THICK stubs
                continue
            hw = int(np.ceil(s.t / 2 + 1))
            if s.o == 'h':
                cov[max(int(s.c) - hw - Y0, 0):int(s.c) + hw + 1 - Y0, max(int(s.a) - X0 - 1, 0):int(s.b) - X0 + 2] = True
            else:
                cov[max(int(s.a) - Y0 - 1, 0):int(s.b) - Y0 + 2, max(int(s.c) - hw - X0, 0):int(s.c) + hw + 1 - X0] = True
        if (ink & ~cov).sum() > 0.35 * ink.sum():
            return None
    tx, ty = pn.tip
    if pn.o == 'v' or (pn.o == 'z' and (ty < y0 or ty > y1)):
        bars = [s for s in rs if s.o == 'h' and s.length >= 0.25 * P.u]
        dist = lambda s: abs(s.c - ty)
    else:
        bars = [s for s in rs if s.o == 'v' and s.length >= 0.25 * P.u]
        dist = lambda s: abs(s.c - tx)
    rows = []
    for s in sorted(bars, key=dist):
        if rows and abs(dist(s) - rows[-1][0]) <= P.t + 1:
            rows[-1][1] = min(rows[-1][1], s.a)
            rows[-1][2] = max(rows[-1][2], s.b)
        else:
            rows.append([dist(s), s.a, s.b])
    if len(rows) >= 2:
        lens = [r[2] - r[1] for r in rows]
        if all(a >= b - P.t for a, b in zip(lens, lens[1:])) and lens[0] > lens[-1] + P.t:
            return 'gnd'
        return None
    if len(rows) == 1 and f['w'] * f['h'] < 2.5 * P.u * P.u:
        return 'v'
    return None


def _looks_gnd(c, S, P):
    return _power_shape(c, S, P) == 'gnd'


def _has_arrows(c, S, P):
    x0, y0, x1, y1 = c.bbox
    sub = (S['glab'][y0:y1 + 1, x0:x1 + 1] > 0)
    # arrows make the bbox clearly non-square relative to the triangle
    f = c.feat
    pins = c.pins
    if len(pins) >= 2:
        o = pins[0].o
        across = f['w'] if o == 'v' else f['h']
        along = f['h'] if o == 'v' else f['w']
        if not across > 1.35 * along:
            return False
        return _arrow_pair(c, S, P) if LED_ARROW_PAIR else True
    return False


LED_ARROW_PAIR = os.environ.get('PCB_LED_ARROWS', '1') == '1'


def _arrow_pair(c, S, P):
    """LED / photodiode: two short parallel diagonal arrows side by side.  A TVS bar with
    bent ends or a dual diode is also wider than tall but has no such pair."""
    m = _body_mask(c, S)
    if m.sum() < 10:
        return False
    u = P.u
    L = cv2.HoughLinesP(m * 255, 1, np.pi / 180, threshold=max(5, int(0.25 * u)),
                        minLineLength=max(5, int(0.45 * u)), maxLineGap=2)
    if L is None:
        return False
    segs = []
    for x1, y1, x2, y2 in np.asarray(L).reshape(-1, 4):
        a = np.degrees(np.arctan2(y2 - y1, x2 - x1)) % 180
        if 20 < a < 70 or 110 < a < 160:
            segs.append((a, (x1 + x2) / 2.0, (y1 + y2) / 2.0))
    for i in range(len(segs)):
        for j in range(i + 1, len(segs)):
            a1, xa, ya = segs[i]
            a2, xb, yb = segs[j]
            if abs(a1 - a2) > 8:
                continue
            t = np.radians(a1)
            d = np.array([xb - xa, yb - ya])
            perp = abs(-np.sin(t) * d[0] + np.cos(t) * d[1])
            par = abs(np.cos(t) * d[0] + np.sin(t) * d[1])
            if 0.15 * u <= perp <= 0.9 * u and par <= 0.8 * u:
                return True
    return False


# ------------------------------------------------------------------ box pin numbering
def assign_box_pins(c, items, P, S, lib):
    u = P.u
    t = P.t
    x0, y0, x1, y1 = c.bbox
    # zero-length pins on a box: infer orientation and base from the body outline
    for pn in c.pins:
        if pn.o == 'z':
            tx, ty = pn.tip
            dx = x0 - tx if tx < x0 else (tx - x1 if tx > x1 else 0)
            dy = y0 - ty if ty < y0 else (ty - y1 if ty > y1 else 0)
            if dx >= dy and dx > 0:
                pn.o = 'h'
                pn.base = (x0 if tx < x0 else x1, ty)
            elif dy > 0:
                pn.o = 'v'
                pn.base = (tx, y0 if ty < y0 else y1)
            else:
                continue
            d = np.array(pn.tip, float) - np.array(pn.base, float)
            n = np.linalg.norm(d)
            pn.dir = tuple(d / n) if n > 0 else (0.0, 0.0)
    pool = [it for it in items if it.text and box_gap(tbox(it), c.bbox) <= 1.5 * u]
    # --- pin numbers: one-to-one assignment of number-like texts to pin stubs
    nums = [it for it in pool if re.match(r'^[A-Z]{0,2}\d{1,3}[A-Z]?$', it.text) and it.color != 'blue'
            and not (x0 + 2 < it.cx < x1 - 2 and y0 + 2 < it.cy < y1 - 2)]
    pins = [pn for pn in c.pins if pn.o in ('h', 'v')]
    if nums and pins:
        # group pins by side; for each side try 'number before' / 'number after' the line
        sides = {}
        for pn in pins:
            key = (pn.o, 1 if (pn.dir[0] + pn.dir[1]) > 0 else -1)
            sides.setdefault(key, []).append(pn)
        used_nums = set()
        for key, sp in sides.items():
            best = None
            for hyp in (-1, 1):
                C = np.full((len(sp), len(nums)), 1e6)
                for i, pn in enumerate(sp):
                    tx, ty = pn.tip
                    bx, by = pn.base
                    for j, it in enumerate(nums):
                        if j in used_nums:
                            continue
                        if pn.o == 'h':
                            lo, hi = min(tx, bx), max(tx, bx)
                            along = max(lo - it.cx, 0, it.cx - hi)
                            gap = (by - it.y1) if hyp < 0 else (it.y0 - by)
                        else:
                            lo, hi = min(ty, by), max(ty, by)
                            along = max(lo - it.cy, 0, it.cy - hi)
                            gap = (bx - it.x1) if hyp < 0 else (it.x0 - bx)
                        if gap < -0.2 * u or gap > 0.5 * u or along > 0.5 * u:
                            continue
                        C[i, j] = abs(gap - 0.1 * u) + 0.5 * along
                r, cc = linear_sum_assignment(C)
                pairs = [(i, j) for i, j in zip(r, cc) if C[i, j] < 1e5]
                cost = sum(C[i, j] for i, j in pairs) / u
                score = len(pairs) - 0.1 * cost
                if best is None or score > best[0]:
                    best = (score, pairs)
            for i, j in best[1]:
                sp[i].num = nums[j].text
                used_nums.add(j)
    # --- pin names: text inside the body next to the pin base
    names = [it for it in pool if (x0 - 2 <= it.cx <= x1 + 2) and (y0 - 2 <= it.cy <= y1 + 2)]
    if names and pins:
        C = np.full((len(pins), len(names)), 1e6)
        for i, pn in enumerate(pins):
            bx, by = pn.base
            for j, it in enumerate(names):
                cx, cy = it.cx, it.cy
                if pn.o == 'h':
                    if abs(cy - by) > 0.45 * u:
                        continue
                    edge = it.x0 if bx <= (x0 + x1) / 2 else it.x1
                    d = abs(edge - bx) / u + abs(cy - by) / u
                    if it.vert:
                        d += 1.0
                else:
                    if abs(cx - bx) > 0.45 * u:
                        continue
                    edge = it.y0 if by <= (y0 + y1) / 2 else it.y1
                    d = abs(edge - by) / u + abs(cx - bx) / u
                    if not it.vert:
                        d += 0.5
                if d > 2.5:
                    continue
                C[i, j] = d
        r, cc = linear_sum_assignment(C)
        for i, j in zip(r, cc):
            if C[i, j] < 1e5:
                pins[i].name = names[j].text
    if lib is not None:
        lib.correct(c)


def trim_stems(c, S, P):
    """Remove leftover straight pin-line portions at both ends of a 2-pin body along its axis."""
    if len(c.pins) != 2:
        return
    a, b = c.pins
    horiz = abs(a.tip[0] - b.tip[0]) > abs(a.tip[1] - b.tip[1])
    x0, y0, x1, y1 = [int(round(v)) for v in c.bbox]
    if x1 <= x0 or y1 <= y0:
        return
    m = np.isin(S['glab'][y0:y1 + 1, x0:x1 + 1], c.gids)
    if m.sum() == 0:
        return
    prof = m.any(0) if False else None
    # perpendicular span of every slice along the axis
    if horiz:
        span = np.array([(np.ptp(np.nonzero(m[:, i])[0]) + 1) if m[:, i].any() else 0 for i in range(m.shape[1])])
    else:
        span = np.array([(np.ptp(np.nonzero(m[i, :])[0]) + 1) if m[i, :].any() else 0 for i in range(m.shape[0])])
    thin = span <= 1.6 * P.t + 1
    lo = 0
    while lo < len(span) and thin[lo]:
        lo += 1
    hi = len(span) - 1
    while hi > lo and thin[hi]:
        hi -= 1
    if hi - lo < 0.3 * P.u:
        return
    if horiz:
        c.bbox[0], c.bbox[2] = x0 + lo, x0 + hi
    else:
        c.bbox[1], c.bbox[3] = y0 + lo, y0 + hi


PIN_LEN_TYPES = {'mosfet': 1.0, 'bjt': 1.0}
SWITCH_CLAMP = os.environ.get('PCB_SW_CLAMP', '1') == '1'


def _extend_to_pin_length(c, u, L):
    """Symbol bodies end one pin length inside the pin tips (EasyEDA library convention:
    10-unit pins); grow the box where we cut away part of the body as 'pin'."""
    x0, y0, x1, y1 = c.bbox
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    for pn in c.pins:
        tx, ty = pn.tip
        if pn.o == 'h' or (pn.o == 'z' and abs(tx - cx) > abs(ty - cy)):
            if tx < cx:
                c.bbox[0] = min(c.bbox[0], tx + L * u)
            else:
                c.bbox[2] = max(c.bbox[2], tx - L * u)
        elif pn.o == 'v' or pn.o == 'z':
            if ty < cy:
                c.bbox[1] = min(c.bbox[1], ty + L * u)
            else:
                c.bbox[3] = max(c.bbox[3], ty - L * u)


def refine_bbox(c, P):
    u = P.u
    if c.type in PIN_LEN_TYPES:
        _extend_to_pin_length(c, u, PIN_LEN_TYPES[c.type])
    if c.type == 'switch' and SWITCH_CLAMP:
        # pin bars drawn as one stroke with the body: the body ends a pin length (>= 1u)
        # inside the tips
        x0, y0, x1, y1 = c.bbox
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        nb = list(c.bbox)
        near = 0.35 * u          # only where the body really runs out to the tip
        for pn in c.pins:
            tx, ty = pn.tip
            if pn.o == 'h':
                if tx <= cx and tx <= x0 + near:
                    nb[0] = max(nb[0], tx + 0.95 * u)
                elif tx > cx and tx >= x1 - near:
                    nb[2] = min(nb[2], tx - 0.95 * u)
            elif pn.o == 'v':
                if ty <= cy and ty <= y0 + near:
                    nb[1] = max(nb[1], ty + 0.95 * u)
                elif ty > cy and ty >= y1 - near:
                    nb[3] = min(nb[3], ty - 0.95 * u)
        if nb[2] - nb[0] >= 0.5 * u and nb[3] - nb[1] >= 0.2 * u:
            c.bbox = nb
    if c.type in ('gnd', 'v') and len(c.pins) == 1:
        tx, ty = c.pins[0].tip
        x0, y0, x1, y1 = c.bbox
        if c.type == 'v':
            ext = 0.45 * u      # power port: the bbox covers part of the stub
            if tx < x0:
                c.bbox[0] = max(tx, x0 - ext)
            elif tx > x1:
                c.bbox[2] = min(tx, x1 + ext)
            elif ty < y0:
                c.bbox[1] = max(ty, y0 - ext)
            elif ty > y1:
                c.bbox[3] = min(ty, y1 + ext)
        else:
            ext = 0.3 * u       # ground: the bbox has a margin below the last bar
            if tx < x0:
                c.bbox[2] = x1 + ext
            elif tx > x1:
                c.bbox[0] = x0 - ext
            elif ty < y0:
                c.bbox[3] = y1 + ext
            elif ty > y1:
                c.bbox[1] = y0 - ext
    if c.type in ('r', 'c', 'd') and len(c.pins) == 2:
        a, b = c.pins
        if a.o == b.o == 'h' or (abs(a.tip[0] - b.tip[0]) > abs(a.tip[1] - b.tip[1]) and a.o != 'v'):
            lo, hi = sorted([a.tip[0], b.tip[0]])
            if hi - lo > 2.2 * u:
                c.bbox[0], c.bbox[2] = lo + u, hi - u
        else:
            lo, hi = sorted([a.tip[1], b.tip[1]])
            if hi - lo > 2.2 * u:
                c.bbox[1], c.bbox[3] = lo + u, hi - u


def pick_name(c, pool, used, u, lib):
    """Choose the part-name text of a component (IC name / part number)."""
    rect = c.bbox
    cands = []
    dg = c.desig_item

    def _under_desig(it):
        # designator-like text that no component claimed, stacked right under/over the
        # designator and aligned with it, is the part number (SS34, US1M, BAT54C)
        if dg is None or it.vert or dg.vert:
            return False
        h = max(dg.h, it.h)
        return (abs(it.x0 - dg.x0) <= 0.3 * u or abs(it.cx - dg.cx) <= 0.3 * u) and 0 < abs(it.cy - dg.cy) <= 1.8 * h

    free = [it for it in pool if it.id not in used and
            (not is_desig(it.text) or (lib is not None and len(it.text) >= 5 and lib.match_name(it.text, 0.0))
             or _under_desig(it))]
    # single items and horizontally adjacent pairs (names with spaces)
    for it in free:
        cands.append(([it], it.text))
    for a in free:
        for b in free:
            if a is b or a.vert or b.vert:
                continue
            ch = max(a.h, b.h)
            if abs(a.cy - b.cy) <= 0.35 * ch and 0 <= b.x0 - a.x1 <= 1.3 * ch:
                cands.append(([a, b], a.text + ' ' + b.text))
    best = None
    for its, txt in cands:
        x0 = min(i.x0 for i in its); y0 = min(i.y0 for i in its)
        x1 = max(i.x1 for i in its); y1 = max(i.y1 for i in its)
        bb = [x0, y0, x1, y1]
        # inside the body (pin names) -> skip unless it is a library name
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        inside = rect[0] + 2 < cx < rect[2] - 2 and rect[1] + 2 < cy < rect[3] - 2
        d = box_gap(rect, bb)
        if c.desig_item is not None:
            d = min(d, box_gap(tbox(c.desig_item), bb) * 0.8)
        if d > 3.0 * u:
            continue
        sc = d / u
        libname = lib.match_name(txt, 0.12) if (lib is not None and len(txt) >= 4 and not is_power_name(txt)) else None
        conf = min((i.conf for i in its), default=0.0)
        keep_txt = False
        if libname and libname != txt and conf >= 0.97:
            from .library import canon, lev as _lev
            keep_txt = _lev(canon(txt), canon(libname)) > 1     # confident read of a different part
        if libname:
            sc -= 2.0 + 0.05 * len(txt)
        elif inside:
            continue
        if is_power_name(txt) and not libname:
            sc += 1.5
        if not libname and any(_on_wire(i, _P_CTX[0]) for i in its):
            sc += 1.5
        if c.desig_item is not None:
            dg = c.desig_item
            if abs(x0 - dg.x0) <= 0.3 * u or abs(x1 - dg.x1) <= 0.3 * u:
                sc -= 0.4                     # left/right aligned with the designator
            elif abs((y0 + y1) / 2 - dg.cy) < 0.5 * dg.h:
                sc += 0.4                     # same row but not aligned: usually another label
        if is_value(txt) and not libname:
            sc += 0.8
        if len(its) == 2 and not libname:
            sc += 1.0
        if libname and _LIB_STRICT and not _confusable_only(txt, libname):
            keep_txt = True        # a different part of the same family: keep what is printed
        if best is None or sc < best[0]:
            best = (sc, txt if keep_txt else (libname or txt), its)
    if best is None:
        return None
    # no printed name: the nearest text is a net label / pin text -> Name falls back to the designator
    if c.type == 'box' and best[0] > NAME_MAX_BOX:
        NAME_LOG.append((c.key, c.type, round(best[0], 2), None, False, len(c.pins), best[1]))
        return None
    if c.type != 'box' and best[0] > 1.0 and not (best[0] < 2.0 and _partnumber_like(best[1], best[2])):
        NAME_LOG.append((c.key, c.type, round(best[0], 2), None, False, len(c.pins), best[1]))
        return None
    NAME_LOG.append((c.key, c.type, round(best[0], 2), best[1], bool(libname_of(best)), len(c.pins), best[1]))
    c.name_conf = min((i.conf for i in best[2]), default=0.0)
    return best[1], best[2]


NAME_LOG = []
from .library import STRICT as _LIB_STRICT, confusable_only as _confusable_only  # noqa: E402
NAME_MAX_BOX = 1.25
_PN_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9\-_.+/()]{5,}$')


def _partnumber_like(txt, its):
    return (bool(_PN_RE.match(txt)) and any(ch.isdigit() for ch in txt) and any(ch.isalpha() for ch in txt)
            and not is_value(txt) and not is_power_name(txt) and not any(_on_wire(i, _P_CTX[0]) for i in its))


def libname_of(best):
    return best[1] != ' '.join(i.text for i in best[2])


def _is_flag(c, P):
    """Net-label flag: an elongated closed polygon with the pin on a short side."""
    f = c.feat
    if not f['holes']:
        return False
    w, h = f['w'], f['h']
    big = max(f['holes'], key=lambda x: x[0])
    a, bw, bh, rect = big
    if a < 0.2 * w * h:
        return False
    if rect > 0.88:
        return False
    if max(w, h) < 1.6 * min(w, h):
        return False
    pn = c.pins[0]
    horiz = w > h
    tx, ty = pn.tip
    x0, y0, x1, y1 = c.bbox
    if horiz:
        return abs(ty - (y0 + y1) / 2) <= 0.3 * h + 2 and (tx <= x0 + 0.25 * w or tx >= x1 - 0.25 * w)
    return abs(tx - (x0 + x1) / 2) <= 0.3 * w + 2 and (ty <= y0 + 0.25 * h or ty >= y1 - 0.25 * h)


def _align_pen(c, it, u):
    """A flag's label is centred on the flag's axis (the pin line); in a stack of flags the
    neighbour's label is just as close by box distance, so misalignment decides."""
    pn = c.pins[0]
    if pn.o == 'h':
        off = abs(it.cy - pn.tip[1])
    elif pn.o == 'v':
        off = abs(it.cx - pn.tip[0])
    else:
        return 0.0
    return 1.5 * off


def _side_pen(c, it, u):
    """Penalty when a label text lies on the pin side of a one-pin symbol."""
    pn = c.pins[0]
    x0, y0, x1, y1 = c.bbox
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    vx, vy = pn.tip[0] - cx, pn.tip[1] - cy
    tx, ty = it.cx - cx, it.cy - cy
    n = (vx * vx + vy * vy) ** 0.5
    if n < 1e-6:
        return 0.0
    proj = (tx * vx + ty * vy) / n
    return 0.6 * u if proj > 0.3 * u else 0.0


ONE_PIN_TYPES = ('gnd', 'v', 'net_bidirection', 'net_input', 'net_output', 'net_short')


def fix_contacts(comps, P):
    """Place the contact point of two directly touching pins using pin-length
    conventions: power/net symbols have zero-length pins, R/IC pins are 1u long."""
    u = P.u
    owner = {}
    for c in comps:
        for pn in c.pins:
            owner[id(pn)] = c
    done = set()
    for c in comps:
        for pa in c.pins:
            pb = getattr(pa, 'mate', None)
            if pb is None or id(pa) in done or id(pb) not in owner:
                continue
            done.add(id(pa)); done.add(id(pb))
            ca, cb = c, owner[id(pb)]
            if pa.seg is None and pb.seg is None:
                continue
            # link geometry
            if pa.seg is not None and pb.seg is not None and pa.seg is pb.seg:
                A, B = pa.base, pb.base
            else:
                # one side is a zero pin sitting on the other body
                continue
            dx, dy = B[0] - A[0], B[1] - A[1]
            L = (dx * dx + dy * dy) ** 0.5
            if L < 1e-6:
                continue
            ux, uy = dx / L, dy / L
            tip = None
            NETS = ('net_bidirection', 'net_input', 'net_output', 'net_short')
            if ca.type in NETS and cb.type not in NETS:
                tip = A
            elif cb.type in NETS and ca.type not in NETS:
                tip = B
            elif 1.6 * u <= L <= 2.4 * u:
                tip = ((A[0] + B[0]) / 2, (A[1] + B[1]) / 2)
            elif ca.type in ('r', 'box') and cb.type not in ('r', 'box') and L >= 0.8 * u:
                d = min(u, L)
                tip = (A[0] + ux * d, A[1] + uy * d)
            elif cb.type in ('r', 'box') and ca.type not in ('r', 'box') and L >= 0.8 * u:
                d = min(u, L)
                tip = (B[0] - ux * d, B[1] - uy * d)
            if tip is not None:
                pa.tip = tuple(tip)
                pb.tip = tuple(tip)


BODY_ALL_GIDS = os.environ.get('PCB_BODY_ALL', '1') == '1'


def _body_mask(c, S):
    if not BODY_ALL_GIDS or len(c.gids) == 1:
        x0, y0, x1, y1 = [int(round(v)) for v in S['groups'][c.gids[0]]['bbox']]
        return (S['glab'][y0:y1 + 1, x0:x1 + 1] == c.gids[0]).astype(np.uint8)
    # merged pieces (MOSFET + body diode, gate + channel): the whole symbol
    bbs = [S['groups'][g]['bbox'] for g in c.gids if g in S['groups'] or isinstance(S['groups'], list)]
    x0 = int(round(min(b[0] for b in bbs))); y0 = int(round(min(b[1] for b in bbs)))
    x1 = int(round(max(b[2] for b in bbs))); y1 = int(round(max(b[3] for b in bbs)))
    return np.isin(S['glab'][y0:y1 + 1, x0:x1 + 1], list(c.gids)).astype(np.uint8)


def _n_diagonals(c, S, P):
    """Number of distinct diagonal strokes (>= 0.45u) in the body."""
    m = _body_mask(c, S)
    if m.sum() < 10:
        return 0
    L = cv2.HoughLinesP(m * 255, 1, np.pi / 90, threshold=max(6, int(0.3 * P.u)),
                        minLineLength=max(6, int(0.45 * P.u)), maxLineGap=2)
    if L is None:
        return 0
    L = np.asarray(L).reshape(-1, 4)
    angs = []
    for x1, y1, x2, y2 in L:
        a = np.degrees(np.arctan2(y2 - y1, x2 - x1)) % 180
        if 15 < a < 75 or 105 < a < 165:
            if not any(abs(a - b) < 10 for b in angs):
                angs.append(a)
    return len(angs)


AMP_TRIANGLE = os.environ.get('PCB_AMP_TRI', '1') == '1'


def _amp_triangle(c, S, P):
    """Op-amp body: the outline itself is a triangle - two long slanted sides of opposite
    slope spanning the body.  An opto-coupler / LED driver drawn in a rectangle only has
    short diagonals (LED triangle, transistor, arrows) relative to its body."""
    m = _body_mask(c, S)
    if m.sum() < 10:
        return False
    h, w = m.shape
    ext = max(h, w)
    L = cv2.HoughLinesP(m * 255, 1, np.pi / 180, threshold=max(8, int(0.3 * ext)),
                        minLineLength=max(8, int(0.5 * ext)), maxLineGap=3)
    if L is None:
        return False
    angs = []
    for x1, y1, x2, y2 in np.asarray(L).reshape(-1, 4):
        a = np.degrees(np.arctan2(y2 - y1, x2 - x1)) % 180
        if 15 < a < 75 or 105 < a < 165:
            angs.append(a)
    for a in angs:
        for b in angs:
            if abs((a + b) - 180) <= 14 and abs(a - b) > 20:
                return True
    return False


def _has_gate_gap(c, S, P):
    """MOSFET gate: two parallel straight strokes separated by a small gap."""
    m = _body_mask(c, S)
    h, w = m.shape
    for arr in (m, m.T):
        cols = arr.sum(0)
        long_cols = np.where(cols >= 0.8 * P.u)[0]
        if len(long_cols) >= 2:
            groups = np.split(long_cols, np.where(np.diff(long_cols) > 1)[0] + 1)
            if len(groups) >= 2:
                centers = [g.mean() for g in groups]
                for a, b in zip(centers, centers[1:]):
                    if 0.15 * P.u <= b - a <= 0.5 * P.u:
                        return True
    return False


def _piece_bbox_map(pieces):
    ys, xs = np.nonzero(pieces)
    labs = pieces[ys, xs]
    n = int(pieces.max()) + 1
    bb = np.zeros((n, 4), np.int64)
    bb[:, 0] = 1 << 30; bb[:, 1] = 1 << 30; bb[:, 2] = -1; bb[:, 3] = -1
    np.minimum.at(bb[:, 0], labs, xs); np.minimum.at(bb[:, 1], labs, ys)
    np.maximum.at(bb[:, 2], labs, xs); np.maximum.at(bb[:, 3], labs, ys)
    area = np.bincount(labs, minlength=n)
    return bb, area


def _merge_contact_pieces(final, used_text):
    """A 1-pin 'part' whose only pin is a direct contact with a diode/LED is a piece of
    that diode (cathode-bar extension touching the light arrows), not a net label."""
    owner = {}
    for c in final:
        for pn in c.pins:
            owner[id(pn)] = c
    keep = []
    drop = set()
    for c in final:
        if len(c.pins) == 1 and c.type not in ('gnd', 'v') and c.pins[0].mate is not None:
            host = owner.get(id(c.pins[0].mate))
            if host is not None and host is not c and host.type in ('led', 'd', 'opt') and len(host.pins) > 2:
                host.pins = [q for q in host.pins if q is not c.pins[0].mate]
                host.bbox = [min(host.bbox[0], c.bbox[0]), min(host.bbox[1], c.bbox[1]),
                             max(host.bbox[2], c.bbox[2]), max(host.bbox[3], c.bbox[3])]
                host.gids = host.gids + c.gids
                if c.label_item is not None:
                    used_text.discard(c.label_item.id)
                if c.desig_item is not None:
                    used_text.discard(c.desig_item.id)
                drop.add(id(c))
                continue
    return [c for c in final if id(c) not in drop]


def reassign_arrows(comps, S, P):
    """Small arrow pieces belong to the nearest LED / photo device, not to whatever
    anchored piece happened to be closest (dense layouts)."""
    leds = [c for c in comps if c.type in ('led', 'opt')]
    if not leds or 'pieces' not in S:
        return
    u = P.u
    pieces = S['pieces']
    glab = S['glab']
    bb, area = _piece_bbox_map(pieces)
    gid_of = {}
    for c in comps:
        for g in c.gids:
            gid_of[g] = c
    pin_pieces = set()
    for c in comps:
        for pn in c.pins:
            x, y = int(round(pn.base[0])), int(round(pn.base[1]))
            win = pieces[max(y - 3, 0):y + 4, max(x - 3, 0):x + 4]
            pin_pieces.update(int(v) for v in np.unique(win) if v > 0)
    moved = {}
    for pc in range(1, len(area)):
        if area[pc] == 0 or pc in pin_pieces:
            continue
        w = bb[pc, 2] - bb[pc, 0] + 1
        h = bb[pc, 3] - bb[pc, 1] + 1
        if max(w, h) > 1.5 * u or max(w, h) < 0.25 * u:
            continue
        if area[pc] > 0.45 * w * h:
            continue
        # owner group of this piece
        y0, x0 = bb[pc, 1], bb[pc, 0]
        sub = (pieces[bb[pc, 1]:bb[pc, 3] + 1, bb[pc, 0]:bb[pc, 2] + 1] == pc)
        lab_vals = glab[bb[pc, 1]:bb[pc, 3] + 1, bb[pc, 0]:bb[pc, 2] + 1][sub]
        owner_g = int(np.bincount(lab_vals).argmax()) if lab_vals.size else 0
        owner = gid_of.get(owner_g)
        if owner is not None and owner.type in ('led', 'opt'):
            continue
        pbox = [bb[pc, 0], bb[pc, 1], bb[pc, 2], bb[pc, 3]]
        best = None
        for c in leds:
            body = c.body_bbox if hasattr(c, 'body_bbox') else c.bbox
            d = box_gap(body, pbox)
            if d <= 1.0 * u and (best is None or d < best[0]):
                best = (d, c)
        if best is None:
            continue
        if owner is not None and box_gap(owner.bbox, pbox) + 0.05 * u < best[0] and owner.type not in ('r', 'c', 'l', 'box'):
            continue
        moved.setdefault(id(best[1]), (best[1], []))[1].append(pbox)
        if owner is not None:
            owner.removed = getattr(owner, 'removed', []) + [pc]
    for c, boxes in moved.values():
        for b in boxes:
            c.bbox = [min(c.bbox[0], b[0]), min(c.bbox[1], b[1]), max(c.bbox[2], b[2]), max(c.bbox[3], b[3])]
    # owners losing pieces: recompute their bbox from the remaining pixels
    for c in comps:
        rem = getattr(c, 'removed', None)
        if not rem:
            continue
        g = c.gids[0]
        x0, y0, x1, y1 = [int(v) for v in S['groups'][g]['bbox']]
        m = (glab[y0:y1 + 1, x0:x1 + 1] == g) & ~np.isin(pieces[y0:y1 + 1, x0:x1 + 1], rem)
        ys, xs = np.nonzero(m)
        if len(ys):
            c.bbox = [x0 + xs.min(), y0 + ys.min(), x0 + xs.max(), y0 + ys.max()]


def _on_wire(it, P):
    """Plain net-name text sits on (or right above) a wire."""
    t = P.t
    for w in P.wires:
        if it.vert:
            if w.o != 'v':
                continue
            if it.x0 - 2 * t <= w.c <= it.x1 + 2 * t and min(w.b, it.y1) - max(w.a, it.y0) >= 0.5 * it.h:
                return True
        else:
            if w.o != 'h':
                continue
            if it.y0 - 2 * t <= w.c <= it.y1 + 2 * t and min(w.b, it.x1) - max(w.a, it.x0) >= 0.5 * it.w:
                return True
    return False


def _body_center_along(c, S, P, horiz):
    """Centre of the symbol body along the pin axis, ignoring straight stems."""
    x0, y0, x1, y1 = [int(round(v)) for v in S['groups'][c.gids[0]]['bbox']]
    m = np.isin(S['glab'][y0:y1 + 1, x0:x1 + 1], c.gids)
    if not m.any():
        return None
    if horiz:
        span = np.array([(np.ptp(np.nonzero(m[:, i])[0]) + 1) if m[:, i].any() else 0 for i in range(m.shape[1])])
    else:
        span = np.array([(np.ptp(np.nonzero(m[i, :])[0]) + 1) if m[i, :].any() else 0 for i in range(m.shape[0])])
    wide = np.nonzero(span > 1.6 * P.t + 1)[0]
    if len(wide) == 0:
        return None
    return (x0 if horiz else y0) + (wide[0] + wide[-1]) / 2.0


def standard_contact_tips(comps, S, P):
    """Capacitors / resistors touching another symbol directly: the touching point is
    at the standard pin length from the body (C: centre +- 2u, R: centre +- 2u)."""
    u = P.u
    for c in comps:
        if c.type not in ('c',) or len(c.pins) != 2:
            continue
        a, b = c.pins
        horiz = abs(a.tip[0] - b.tip[0]) > abs(a.tip[1] - b.tip[1])
        cen = _body_center_along(c, S, P, horiz)
        if cen is None:
            continue
        for pn in (a, b):
            if pn.kind not in ('contact', 'zero') or pn.term is not None:
                continue
            k = 0 if horiz else 1
            side = 1 if pn.tip[k] > cen else -1
            new = cen + side * 2 * u
            if abs(new - pn.tip[k]) > 0.6 * u:
                continue
            tip = list(pn.tip)
            tip[k] = new
            pn.tip = tuple(tip)
            m = getattr(pn, 'mate', None)
            if m is not None:
                mt = list(m.tip)
                mt[k] = new
                m.tip = tuple(mt)
