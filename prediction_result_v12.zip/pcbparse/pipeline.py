"""End-to-end schematic image -> competition JSON."""
import os
import json
import time
import math
import numpy as np
import cv2

from .prims import extract
from .wiregraph import build_lines, snap_and_connect, decompose_edges, UF
from .sym import segment_symbols, estimate_unit
from .text import merge_fragments, build_text_items, ocr_items
from .assemble import build
from .library import Library

_HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_LIBS = [os.path.join(os.path.dirname(_HERE), 'data', 'BoxICLibrary.json'),
                os.path.join(os.path.dirname(_HERE), 'data', 'cpntLibrary.json'),
                # IC pin maps of the official 200 training cases not in the two libraries above
                # (Q&A: every IC of the test set appears in the 200 cases or in cpntLibrary)
                os.path.join(os.path.dirname(_HERE), 'data', 'trainLibrary.json')]
_LIB = None
MERGE_POWER = os.environ.get('PCB_MERGE_POWER', '1') == '1'
DUP_SUFFIX = os.environ.get('PCB_DUP_SUFFIX', '1') == '1'


def get_lib():
    global _LIB
    if _LIB is None:
        _LIB = Library([p for p in os.environ.get('PCB_LIBS', '').split(os.pathsep) if p] + DEFAULT_LIBS)
    return _LIB


def load_image(path):
    data = np.fromfile(path, dtype=np.uint8)
    im = cv2.imdecode(data, cv2.IMREAD_UNCHANGED)
    if im is None:
        raise IOError(path)
    if im.ndim == 2:
        im = cv2.cvtColor(im, cv2.COLOR_GRAY2BGR)
    if im.shape[2] == 4:
        alpha = im[:, :, 3:4].astype(np.float32) / 255.0
        bg = np.array([247, 252, 255], np.float32)  # BGR paper colour
        im = (im[:, :, :3].astype(np.float32) * alpha + bg * (1 - alpha)).astype(np.uint8)
    return im[:, :, ::-1].copy()  # RGB


SAFE_FLAGS = [('text', 'UNDERSCORE_JOIN'), ('text', 'STRIP_RUNS'), ('text', 'CASE_FIX'), ('text', 'DOT_FIX'),
              ('assemble', 'MERGE_TOUCHING'), ('assemble', 'MERGE_SWITCH_PIECES'), ('assemble', 'CARVE_FLAGS'),
              ('assemble', 'DESIG_CONSIST'), ('assemble', 'RECT_COMPARTMENTS'), ('assemble', 'LED_ARROW_PAIR'),
              ('assemble', 'AMP_TRIANGLE'), ('assemble', 'BODY_ALL_GIDS'), ('assemble', 'SWITCH_CLAMP'),
              ('assemble', 'MERGE_CONTACT_ORPHANS'), ('assemble', 'ORPHAN_DESIG'),
              # refinements added in v10
              ('text', 'UNDERSCORE_VERT'), ('text', 'TALL_VERT'), ('sym', 'GLYPH_CUTS'),
              ('assemble', 'NAME_WORDS'), ('assemble', 'POWER_STEM'), ('assemble', 'EQUAL_PINS'),
              ('assemble', 'MERGE_BODY_PARTS'), ('assemble', 'BODY_STUBS'), ('assemble', 'DROP_NET_TIES'),
              ('assemble', 'SPLIT_PAIRS'), ('assemble', 'SPLIT_STACKS'), ('assemble', 'FAR_DESIG'),
              ('assemble', 'DESIG_LIKE_MODEL'), ('assemble', 'NAME_GLOBAL'), ('assemble', 'ROT_VOTE'),
              ('assemble', 'NUM_SIDE_PRIOR'), ('assemble', 'RECT_CLOSE'), ('assemble', 'RECT_RED_FALLBACK'),
              ('assemble', 'GATE_RELAX'), ('assemble', 'Q_FROM_O'), ('assemble', 'DEDUP_PINS'),
              ('assemble', 'FAR_POWER_NAME'), ('assemble', 'ARROW_TAIL'), ('library', 'LAST_PIN'),
              ('assemble', 'CARVE_FLAGS_SMALL'), ('assemble', 'SMALL_EDGE_PINS'), ('assemble', 'DROP_FRAMES'),
              # refinements added in v11
              ('assemble', 'NAME_ASSIGN'), ('assemble', 'GND_PASSING'), ('assemble', 'GND_BASE_PIX'),
              ('assemble', 'GND_FIRST'), ('assemble', 'GND_HOST_FIX'), ('assemble', 'GND_HOST_BBOX'),
              ('assemble', 'AMP_PINS'), ('assemble', 'STACK_DROP_Z'), ('assemble', 'STACK_Z_ORIENT'),
              ('assemble', 'STACK_PARTIAL'), ('assemble', 'DESIG_STACK_PRIOR'), ('assemble', 'DROP_CONTACT_ISLANDS'),
              ('assemble', 'RECT_PORT'), ('assemble', 'FLAG_DOT_DROP'), ('assemble', 'STACK_PITCH'),
              ('assemble', 'CARVED_GND_NAME'), ('assemble', 'FAR_PWR_SPAN'), ('assemble', 'CAP_UNIT_FIX'),
              ('assemble', 'PASSIVE_PIN_LEN'), ('assemble', 'LEAD_PIECES'), ('assemble', 'MERGE_SKIP_ARROWS'),
              ('textfix', 'OHM_PROB')]


def parse_image(path, debug=False):
    """Parse one image.  If the full pipeline raises, retry once in 'safe mode' with the
    optional refinements switched off, so that a corner case never costs a whole case."""
    try:
        return _parse_image(path, debug)
    except Exception:
        import importlib
        saved = []
        for mod, name in SAFE_FLAGS:
            m = importlib.import_module('.' + mod, __package__)
            if hasattr(m, name):
                saved.append((m, name, getattr(m, name)))
                setattr(m, name, False)
        try:
            return _parse_image(path, debug)
        finally:
            for m, name, v in saved:
                setattr(m, name, v)


def _parse_image(path, debug=False):
    img = load_image(path)
    # drawings in other tools' palettes (Altium, KiCad ...) are repainted in the EasyEDA
    # palette first; EasyEDA images come back untouched.  Any failure keeps the original.
    try:
        from .style import normalise
        img, _style = normalise(img)
    except Exception:
        pass
    P = extract(img)
    f = 1.0
    if P.t < 2.4 and img.shape[0] * img.shape[1] <= 9e6:   # >9 MP: 2x copy would need several GB
        # thin strokes / tiny text: work on a 2x upscaled copy, map coordinates back
        f = 2.0
        img = cv2.resize(img, None, fx=f, fy=f, interpolation=cv2.INTER_CUBIC)
        P = extract(img)
    lines = build_lines(P)
    uf, terms = snap_and_connect(P, lines)
    S = segment_symbols(P, terms, lines)
    u = estimate_unit(P, S)
    if abs(u - P.u) > 0.03 * P.u:
        P.u = u
        P.s = u / 10.0
        S = segment_symbols(P, terms, lines)
    items = build_text_items(P, img)
    ocr_items(P, img, items)
    items = merge_fragments(P, img, items)
    comps = build(P, items, S, lines, uf, terms, lib=get_lib())
    out = to_json(P, comps, lines, uf, S, f)
    if os.environ.get('PCB_NAME_LOG'):
        from . import assemble as _A
        # key -> final key mapping is not needed: NAME_LOG keys are designators before de-dup
        out['_name_log'] = [list(r) for r in _A.NAME_LOG]
    if os.environ.get('PCB_FB_LOG'):
        from . import assemble as _A
        out['_fb_log'] = dict(f=f, H=int(P.H), rows=list(_A.FB_LOG))
    if debug:
        return out, dict(P=P, lines=lines, uf=uf, terms=terms, S=S, items=items, comps=comps)
    return out


def _r(v):
    return int(round(v))


MODEL_NAME_TYPES = ('d', 'led', 'opt', 'zener', 'schottky', 'tvs')
# evaluation spec 2026-10-22, type appendix: 'crystal' and 'amp' do not distinguish pin counts
TYPE_FAMILY_OUT = os.environ.get('PCB_TYPE_FAMILY_OUT', '1') == '1'
OUT_TYPE = {'crystal_2pin': 'crystal', 'crystal_3pin': 'crystal', 'crystal_4pin': 'crystal',
            'amp_3pin': 'amp', 'amp_5pin': 'amp', 'amp_7pin': 'amp'}


def to_json(P, comps, lines, uf, S, f=1.0):
    H = P.H

    def _r(v):
        return int(round(v / f))
    t = P.t
    # ------------------------------------------------ keys
    seen = {}
    anon_n = 0
    order = sorted(comps, key=lambda c: (c.bbox[1], c.bbox[0]))
    groups = {}
    for c in order:
        if c.anon or c.type in ('gnd', 'v') and not c.key:
            anon_n += 1
            c.key = f'∅{anon_n}'
            c.base_key = c.key
            continue
        k = c.key or f'X{len(order) + len(groups) + 1}'
        c.base_key = k
        groups.setdefault((k, c.type.startswith('net')), []).append(c)
    for (k, is_net), lst in groups.items():
        if len(lst) == 1:
            lst[0].key = k
        elif is_net or not DUP_SUFFIX:
            # repeated net-label names: X, X_2, X_3 ... (reading order)
            for i, c in enumerate(lst, 1):
                c.key = k if i == 1 else f'{k}_{i}'
        else:
            # one designator on several parts (units of a multi-part IC, or two symbols sharing
            # a designator): the official labels key them <desig>_1, _2 ... from left to right
            lst.sort(key=lambda c: (c.bbox[0], c.bbox[1]))
            for i, c in enumerate(lst, 1):
                c.key = f'{k}_{i}'
    keys = [c.key for c in comps]
    if len(set(keys)) != len(keys):        # a suffixed key colliding with a printed one
        used = set()
        for c in order:
            k = c.key
            j = 2
            while k in used:
                k = f'{c.key}_{j}'
                j += 1
            c.key = k
            used.add(k)
    # ------------------------------------------------ pin numbering
    from .assemble import AMP_PINS
    for c in comps:
        if c.type in ('box', 'switch') or (AMP_PINS and c.type.startswith('amp')):
            used = set()
            for pn in c.pins:
                if pn.num and pn.num not in used:
                    used.add(pn.num)
                else:
                    pn.num = None
            # pin numbers hidden but the pin names are numbers (connectors / headers): the name
            # is the number
            for pn in c.pins:
                if pn.num is None and pn.name and str(pn.name).isdigit() and pn.name not in used:
                    pn.num = str(pn.name)
                    used.add(pn.num)
            k = 1
            for pn in sorted(c.pins, key=lambda p: (p.tip[0], p.tip[1])):
                if pn.num is None:
                    while str(k) in used:
                        k += 1
                    pn.num = str(k)
                    used.add(pn.num)
                if pn.name is None:
                    pn.name = pn.num
        elif len(c.pins) == 2:
            a, b = c.pins
            # pin_1: left (or bottom), pin_2: right (or top)
            dx = abs(a.tip[0] - b.tip[0])
            dy = abs(a.tip[1] - b.tip[1])
            if dx >= dy:
                first, second = (a, b) if a.tip[0] <= b.tip[0] else (b, a)
            else:
                first, second = (a, b) if a.tip[1] >= b.tip[1] else (b, a)
            first.num, second.num = '1', '2'
            if c.type in ('d', 'led'):
                first.name, second.name = 'A', 'K'
            else:
                first.name, second.name = '1', '2'
        else:
            for k, pn in enumerate(sorted(c.pins, key=lambda p: (p.tip[0], -p.tip[1])), 1):
                pn.num = str(k)
                pn.name = str(k)
        for pn in c.pins:
            pn.comp = c
    # ------------------------------------------------ nets
    L = len(lines)
    allpins = [pn for c in comps for pn in c.pins]
    U = UF(L + len(allpins))
    for a in range(L):
        U.union(a, uf.find(a))
    for i, pn in enumerate(allpins):
        if pn.term is not None:
            U.union(L + i, pn.term['line'])
    # pin-pin contacts
    for i in range(len(allpins)):
        for j in range(i + 1, len(allpins)):
            a, b = allpins[i], allpins[j]
            if a.comp is b.comp:
                continue
            if math.hypot(a.tip[0] - b.tip[0], a.tip[1] - b.tip[1]) <= 1.5 * t + 1.5:
                U.union(L + i, L + j)
    # pins whose tip lies on a junction dot of a wire line (not at a terminal)
    for i, pn in enumerate(allpins):
        if pn.term is not None:
            continue
        for (x, y, r) in P.dots:
            if math.hypot(pn.tip[0] - x, pn.tip[1] - y) <= r + t:
                for ln in lines:
                    uu, d = ln.proj((x, y))
                    if d <= r + t and -0.02 <= uu <= 1.02:
                        U.union(L + i, ln.id)
                        break
    # same-name power / ground symbols are one electrical net (the official scorer
    # merges them as well; merging here is idempotent)
    if MERGE_POWER:
        first = {}
        for i, pn in enumerate(allpins):
            c = pn.comp
            if c.type in ('gnd', 'v'):
                key = (c.type, (c.value or ('GND' if c.type == 'gnd' else '')).upper())
                if key in first:
                    U.union(first[key], L + i)
                else:
                    first[key] = L + i
    groups = {}
    for i, pn in enumerate(allpins):
        groups.setdefault(U.find(L + i), []).append(pn)
    E = decompose_edges(lines)
    line_root = {a: U.find(a) for a in range(L)}
    nets = {}
    k = 0
    for root, pins in sorted(groups.items(), key=lambda kv: min((p.tip[1], p.tip[0]) for p in kv[1])):
        wired = [a for a in range(L) if line_root[a] == root]
        if len(pins) < 2 and not wired:
            continue
        if len(pins) < 2:
            # a lone pin with only a tiny wire remnant (e.g. left over from a no-connect 'X')
            wl = sum(abs(p[0] - q[0]) + abs(p[1] - q[1]) for a in wired for p, q in E[a])
            if wl < 0.8 * P.u:
                continue
        k += 1
        toks = []
        for pn in pins:
            tok = f'{pn.comp.key}.{pn.num}'
            if tok not in toks:
                toks.append(tok)
        edges = {}
        e = 0
        for a in wired:
            for p, q in E[a]:
                e += 1
                edges[f'edge_{e}'] = [{'x': _r(p[0]), 'y': _r(H - p[1])}, {'x': _r(q[0]), 'y': _r(H - q[1])}]
        nets[f'net_{k}'] = {'hyperGraph': '(' + ','.join(toks) + ')', 'edges': edges}
    # ------------------------------------------------ components & pins
    jc, jp = {}, {}
    for c in comps:
        x0, y0, x1, y1 = c.bbox
        bbox = [_r(x0), _r(H - y1), _r(x1), _r(H - y0)]
        # Name convention (verified against the platform scorer, which compares Name and
        # value for every component): part number for ICs / diodes / LEDs (and other
        # semiconductors) when one is printed, otherwise the designator; net labels use
        # their key (incl. _2 suffix); everything else uses the designator.
        base = getattr(c, 'base_key', c.key)
        if c.type == 'box':
            name = c.name if c.name else base
            value = None
        elif c.type in ('gnd', 'v'):
            name = c.key
            value = c.value
        elif c.type.startswith('net'):
            name = c.key
            value = c.value
        elif c.type in MODEL_NAME_TYPES or c.type.startswith(('bjt', 'mosfet', 'amp')):
            name = c.name if c.name else base
            value = c.value
        else:
            name = base
            value = None if c.type == 'switch' else c.value
        jc[c.key] = {'Name': name, 'type': OUT_TYPE.get(c.type, c.type) if TYPE_FAMILY_OUT else c.type,
                     'value': value, 'bbox': bbox}
        pp = {}
        for pn in c.pins:
            pp[f'pin_{pn.num}'] = {'pinname': pn.name if pn.name is not None else pn.num,
                                   'point': {'x': _r(pn.tip[0]), 'y': _r(H - pn.tip[1])}}
        jp[c.key] = pp
    return {'components': jc, 'pins': jp, 'nets': nets}


def _process_one(args):
    path, out_dir = args
    case = os.path.splitext(os.path.basename(path))[0]
    t0 = time.time()
    try:
        out = parse_image(path)
        err = None
    except Exception as e:  # never lose a case
        import traceback
        err = traceback.format_exc()
        out = {'components': {}, 'pins': {}, 'nets': {}}
    d = os.path.join(out_dir, case)
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, case + '.json'), 'w', encoding='utf-8') as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    return case, len(out['components']), len(out['nets']), time.time() - t0, err


def list_images(in_dir):
    cases = []
    for root, dirs, files in os.walk(in_dir):
        for f in files:
            if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')) and not f.startswith('.'):
                cases.append(os.path.join(root, f))
    cases.sort()
    return cases


def run_dir(in_dir, out_dir, verbose=True, workers=None):
    os.makedirs(out_dir, exist_ok=True)
    cases = list_images(in_dir)
    if workers is None:
        workers = int(os.environ.get('PCB_WORKERS', '0')) or max(1, min(len(cases), (os.cpu_count() or 2) // 2, 16))
    jobs = [(p, out_dir) for p in cases]
    if workers <= 1 or len(jobs) <= 1:
        results = map(_process_one, jobs)
    else:
        import multiprocessing as mp
        os.environ.setdefault('OMP_NUM_THREADS', '2')
        ctx = mp.get_context('spawn')
        pool = ctx.Pool(workers)
        results = pool.imap_unordered(_process_one, jobs)
    for case, nc, nn, dt, err in results:
        if verbose:
            print(f'{case}: {nc} comps, {nn} nets, {dt:.1f}s' + (' ERROR' if err else ''), flush=True)
            if err:
                print(err, flush=True)
