"""Text glyph grouping into text items + OCR."""
import numpy as np
import cv2
from .ocr import get_rec


class TextItem:
    __slots__ = ('x0', 'y0', 'x1', 'y1', 'vert', 'color', 'text', 'conf', 'glyphs', 'id', 'used', 'alts', 'probs', 'rot')

    def __init__(self, x0, y0, x1, y1, vert, color, glyphs):
        self.x0, self.y0, self.x1, self.y1 = x0, y0, x1, y1
        self.vert = vert
        self.color = color
        self.glyphs = glyphs
        self.text = ''
        self.conf = 0.0
        self.id = -1
        self.used = False
        self.alts = []
        self.probs = None
        self.rot = 'h'

    @property
    def cx(self):
        return (self.x0 + self.x1) / 2

    @property
    def cy(self):
        return (self.y0 + self.y1) / 2

    @property
    def w(self):
        return self.x1 - self.x0 + 1

    @property
    def h(self):
        return self.y1 - self.y0 + 1

    def __repr__(self):
        return f"T({self.text!r},{self.color},{'V' if self.vert else 'H'},[{self.x0},{self.y0},{self.x1},{self.y1}],{self.conf:.2f})"


def _glyphs(mask, max_h, min_area=2):
    n, lab, st, cen = cv2.connectedComponentsWithStats(mask, connectivity=8)
    out = []
    for i in range(1, n):
        x, y, w, h, a = st[i]
        if a < min_area:
            continue
        if h > max_h and w > max_h:
            continue
        if max(w, h) > 4 * max_h:
            continue
        out.append([int(x), int(y), int(x + w - 1), int(y + h - 1), int(a)])
    return out


def _group(glyphs, ch, vert):
    """Group glyph boxes into lines. ch = typical char height (px)."""
    n = len(glyphs)
    parent = list(range(n))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a
    g = np.array(glyphs, float) if n else np.zeros((0, 5))
    if vert:
        # swap axes: treat y as reading direction
        g = g[:, [1, 0, 3, 2, 4]]
    order = np.argsort(g[:, 0]) if n else []
    for ii, i in enumerate(order):
        for j in order[ii + 1:]:
            if g[j, 0] > g[i, 2] + 0.75 * ch:
                break
            # overlap in cross axis
            ov = min(g[i, 3], g[j, 3]) - max(g[i, 1], g[j, 1])
            hi_ = min(g[i, 3] - g[i, 1], g[j, 3] - g[j, 1]) + 1
            # allow small glyphs (., -, ') whose cross extent is small but inside the line band
            if ov >= 0.45 * hi_ or (ov >= -1 and hi_ < 0.45 * ch):
                gap = g[j, 0] - g[i, 2]
                # cross-axis centre consistency
                c1 = (g[i, 1] + g[i, 3]) / 2
                c2 = (g[j, 1] + g[j, 3]) / 2
                if gap <= 0.62 * ch and abs(c1 - c2) <= 0.5 * ch:
                    parent[find(j)] = find(i)
    groups = {}
    for i in range(n):
        groups.setdefault(find(i), []).append(i)
    return list(groups.values())


def build_text_items(P, img_rgb):
    lab = P.M['lab']
    items = []
    t = P.t
    blue = (lab == 3).astype(np.uint8)
    blk = (lab == 4).astype(np.uint8)
    near_blue = cv2.dilate(blue, np.ones((5, 5), np.uint8))
    # black pixels touching blue glyphs are blended blue text (e.g. text over a wire)
    blk_cc_n, blk_lab = cv2.connectedComponents(blk, connectivity=8)
    touch = np.unique(blk_lab[(near_blue > 0) & (blk > 0)])
    touch = touch[touch > 0]
    blk_blue = np.isin(blk_lab, touch) & (near_blue > 0)
    mask_by_color = {'any': (blue | blk).astype(np.uint8)}
    bluem = (blue | blk_blue)
    for color in ('any',):
        m = mask_by_color[color]
        if m.sum() == 0:
            continue
        # character height estimate
        gl = _glyphs(m, max_h=int(2.2 * P.u))
        if not gl:
            continue
        hs = np.array([b[3] - b[1] + 1 for b in gl])
        ws = np.array([b[2] - b[0] + 1 for b in gl])
        big = hs[(hs >= 0.4 * P.u)]
        ch = float(np.median(big)) if len(big) else 0.75 * P.u
        ch = min(max(ch, 0.45 * P.u), 1.3 * P.u)
        # discard long lines (frames etc.)
        gl = [b for b in gl if not ((b[2] - b[0] > 3 * ch and b[3] - b[1] < 0.25 * ch) or (b[3] - b[1] > 3 * ch and b[2] - b[0] < 0.25 * ch))]
        its = _make_items(gl, ch, color)
        for it in its:
            # drop leading/trailing glyphs of the other colour class (blended line fragments)
            if len(it.glyphs) > 1:
                def isblue(b):
                    sub = bluem[b[1]:b[3] + 1, b[0]:b[2] + 1]
                    tot = m[b[1]:b[3] + 1, b[0]:b[2] + 1]
                    return (sub & (tot > 0)).sum() >= 0.5 * max(tot.sum(), 1)
                key = (lambda b: b[1]) if it.vert else (lambda b: b[0])
                gs = sorted(it.glyphs, key=key)
                flags = [isblue(b) for b in gs]
                maj = sum(flags) >= len(flags) / 2.0
                def frag(b):
                    w_, h_ = b[2] - b[0] + 1, b[3] - b[1] + 1
                    return min(w_, h_) <= max(2, 0.22 * ch)
                while len(gs) > 1 and flags[0] != maj and frag(gs[0]):
                    gs.pop(0); flags.pop(0)
                while len(gs) > 1 and flags[-1] != maj and frag(gs[-1]):
                    gs.pop(); flags.pop()
                if len(gs) != len(it.glyphs):
                    it.glyphs = gs
                    it.x0 = min(b[0] for b in gs); it.y0 = min(b[1] for b in gs)
                    it.x1 = max(b[2] for b in gs); it.y1 = max(b[3] for b in gs)
            nb = 0
            nk = 0
            for b in it.glyphs:
                sub = bluem[b[1]:b[3] + 1, b[0]:b[2] + 1]
                tot = m[b[1]:b[3] + 1, b[0]:b[2] + 1]
                nb += int((sub & (tot > 0)).sum())
                nk += int(tot.sum())
            it.color = 'blue' if nb >= 0.5 * max(nk, 1) else 'black'
            mx = max(max(b[3] - b[1], b[2] - b[0]) + 1 for b in it.glyphs)
            if mx < 0.55 * ch:
                continue
            if sum(b[4] for b in it.glyphs) < 0.12 * ch * ch:
                continue
            items.append(it)
    # red glyph candidates (pin numbers drawn in symbol colour)
    items_red = red_glyph_items(P)
    items += items_red
    for i, it in enumerate(items):
        it.id = i
    return items


def _make_items(gl, ch, color):
    hgroups = _group(gl, ch, False)
    vgroups = _group(gl, ch, True)
    # decide for each glyph whether it belongs to a horizontal or a vertical group
    # score: groups with more glyphs and consistent glyph sizes win
    assign = {}
    cand = []
    for grp in hgroups:
        cand.append(('h', grp))
    for grp in vgroups:
        cand.append(('v', grp))

    def score(o, grp):
        bs = [gl[i] for i in grp]
        if len(grp) == 1:
            b = bs[0]
            w, h = b[2] - b[0] + 1, b[3] - b[1] + 1
            # single glyph: orientation from aspect (rotated glyphs are usually wider)
            return 0.5 if (o == 'h') == (h >= 0.8 * w or h >= 0.7 * ch) else 0.4
        x0 = min(b[0] for b in bs); x1 = max(b[2] for b in bs)
        y0 = min(b[1] for b in bs); y1 = max(b[3] for b in bs)
        extent_cross = (y1 - y0 + 1) if o == 'h' else (x1 - x0 + 1)
        pen = 0.0
        if extent_cross > 1.35 * ch:
            pen = 1.0
        return len(grp) - pen
    cand.sort(key=lambda c: -score(*c))
    items = []
    for o, grp in cand:
        free = [i for i in grp if i not in assign]
        if not free:
            continue
        if len(free) < len(grp):
            # partially used: regroup the free ones on their own later
            continue
        for i in grp:
            assign[i] = o
        bs = [gl[i] for i in grp]
        it = TextItem(min(b[0] for b in bs), min(b[1] for b in bs), max(b[2] for b in bs), max(b[3] for b in bs),
                      o == 'v', color, bs)
        items.append(it)
    left = [i for i in range(len(gl)) if i not in assign]
    if left:
        sub = [gl[i] for i in left]
        for grp in _group(sub, ch, False):
            bs = [sub[i] for i in grp]
            items.append(TextItem(min(b[0] for b in bs), min(b[1] for b in bs), max(b[2] for b in bs), max(b[3] for b in bs),
                                  False, color, bs))
    return items


def red_glyph_items(P):
    """Small isolated red connected components that look like characters."""
    red = P.red
    n, lab, st, cen = cv2.connectedComponentsWithStats(red, connectivity=8)
    gl = []
    u = P.u
    for i in range(1, n):
        x, y, w, h, a = st[i]
        if h < 0.35 * u or h > 1.0 * u or w > 1.0 * u:
            continue
        if a > 0.6 * w * h and w > 0.25 * u:
            continue
        gl.append([int(x), int(y), int(x + w - 1), int(y + h - 1), int(a)])
    if not gl:
        return []
    hs = [b[3] - b[1] + 1 for b in gl]
    ch = float(np.median(hs))
    return _make_items(gl, ch, 'red')


def crop_for_ocr(P, img_rgb, it, pad=None):
    lab = P.M['lab']
    H, W = lab.shape
    hh = it.w if it.vert else it.h
    pad = pad if pad is not None else max(2, int(0.25 * hh))
    x0, y0 = max(it.x0 - pad, 0), max(it.y0 - pad, 0)
    x1, y1 = min(it.x1 + pad, W - 1), min(it.y1 + pad, H - 1)
    mag = P.M['mag'][y0:y1 + 1, x0:x1 + 1]
    sub = lab[y0:y1 + 1, x0:x1 + 1]
    cls = {'blue': 3, 'black': 4, 'red': 1}[it.color]
    keep = np.zeros(sub.shape, bool)
    # keep only glyph boxes' pixels of the item class (+ anti-aliased gray near them)
    gm = np.zeros(sub.shape, bool)
    e = 1
    gm[max(it.y0 - y0 - e, 0):it.y1 - y0 + 1 + e, max(it.x0 - x0 - e, 0):it.x1 - x0 + 1 + e] = True
    keep = gm & ((sub == cls) | (sub == 5) | (sub == 4) | ((sub == 6) & (cls == 1)) | ((sub == 1) & (cls == 1)) | (sub == 3))
    if cls != 4:
        keep &= ~(sub == 2)
    val = np.where(keep, np.clip(mag / 600.0, 0, 1), 0)
    val = _remove_wire_bands(P, val, x0, y0, it)
    g = (255 * (1 - val)).astype(np.uint8)
    crop = cv2.cvtColor(g, cv2.COLOR_GRAY2RGB)
    return crop


def _remove_wire_bands(P, val, x0, y0, it=None):
    """Wires crossing text leave a 'strike-through'; replace wire-band pixels by
    vertical (resp. horizontal) interpolation of the glyph strokes around them."""
    h, w = val.shape
    hw = P.t / 2 + 0.8
    for s_ in P.wires:
        if s_.o == 'h':
            if not (y0 - hw <= s_.c <= y0 + h + hw):
                continue
            if s_.b < x0 or s_.a > x0 + w:
                continue
            if it is not None and not it.vert:
                hh = it.y1 - it.y0 + 1
                if s_.c - it.y0 < 0.22 * hh or it.y1 - s_.c < 0.22 * hh:
                    continue      # wire only grazes the text edge
            r0 = int(np.ceil(s_.c - P.t / 2)) - y0
            r1 = int(np.floor(s_.c + P.t / 2)) - y0
            a = max(int(s_.a) - x0 - 1, 0)
            b = min(int(s_.b) - x0 + 2, w)
            if r1 < 0 or r0 >= h:
                continue
            above = val[r0 - 1, a:b] if r0 - 1 >= 0 else np.zeros(b - a)
            below = val[r1 + 1, a:b] if r1 + 1 < h else np.zeros(b - a)
            fill = np.minimum(above, below)
            for r in range(max(r0, 0), min(r1 + 1, h)):
                val[r, a:b] = fill
        else:
            if not (x0 - hw <= s_.c <= x0 + w + hw):
                continue
            if s_.b < y0 or s_.a > y0 + h:
                continue
            if it is not None and it.vert:
                ww = it.x1 - it.x0 + 1
                if s_.c - it.x0 < 0.22 * ww or it.x1 - s_.c < 0.22 * ww:
                    continue
            c0 = int(np.ceil(s_.c - P.t / 2)) - x0
            c1 = int(np.floor(s_.c + P.t / 2)) - x0
            a = max(int(s_.a) - y0 - 1, 0)
            b = min(int(s_.b) - y0 + 2, h)
            if c1 < 0 or c0 >= w:
                continue
            left = val[a:b, c0 - 1] if c0 - 1 >= 0 else np.zeros(b - a)
            right = val[a:b, c1 + 1] if c1 + 1 < w else np.zeros(b - a)
            fill = np.minimum(left, right)
            for c in range(max(c0, 0), min(c1 + 1, w)):
                val[a:b, c] = fill
    return val


def ocr_items(P, img_rgb, items, rec=None):
    rec = rec or get_rec()
    crops = []
    idx = []
    for it in items:
        c = crop_for_ocr(P, img_rgb, it)
        if it.vert:
            # EasyEDA vertical text reads bottom-to-top (rotated 90deg CCW)
            crops.append(cv2.rotate(c, cv2.ROTATE_90_CLOCKWISE))
            idx.append((it, 'cw'))
            crops.append(cv2.rotate(c, cv2.ROTATE_90_COUNTERCLOCKWISE))
            idx.append((it, 'ccw'))
        else:
            crops.append(c)
            idx.append((it, 'h'))
    res = rec(crops, return_probs=True) if crops else []
    best = {}
    for (it, o), (txt, conf, probs) in zip(idx, res):
        b = best.get(it.id)
        if b is None or conf > b[1]:
            best[it.id] = (txt, conf, probs, o)
    for it in items:
        if it.id in best:
            it.text, it.conf, it.probs, it.rot = best[it.id]
            it.text = it.text.strip()
    return items


def redecode(it, allowed, rec=None):
    rec = rec or get_rec()
    if it.probs is None:
        return it.text, it.conf
    return rec.constrained(it.probs, allowed)
