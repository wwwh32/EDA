"""Primitive extraction: scale, wires, junction dots, unconnected markers, red strokes."""
import numpy as np
import cv2
from .colors import masks
from .geom import extract_segments, Seg


class Prims:
    pass


def estimate_stroke(mask, axis_samples=9):
    m = mask.astype(np.int8)
    runs = []
    for x in range(0, m.shape[1], axis_samples):
        col = m[:, x]
        d = np.diff(np.r_[0, col, 0])
        s = np.where(d == 1)[0]
        e = np.where(d == -1)[0]
        runs += list(e - s)
    for y in range(0, m.shape[0], axis_samples):
        row = m[y, :]
        d = np.diff(np.r_[0, row, 0])
        s = np.where(d == 1)[0]
        e = np.where(d == -1)[0]
        runs += list(e - s)
    runs = np.array([r for r in runs if 1 <= r <= 12])
    if len(runs) == 0:
        return 3.0
    c = np.bincount(runs, minlength=13).astype(float)
    k = int(np.argmax(c))
    # sub-pixel estimate around mode
    lo, hi = max(k - 1, 1), min(k + 1, 12)
    w = c[lo:hi + 1]
    return float((np.arange(lo, hi + 1) * w).sum() / w.sum())


def find_junctions(red, green, t):
    """Junction dots: filled red discs sitting on wires."""
    dt = cv2.distanceTransform((red > 0).astype(np.uint8), cv2.DIST_L2, 5)
    thr = max(1.5, 0.95 * t)
    core = (dt >= thr).astype(np.uint8)
    n, lab, st, cen = cv2.connectedComponentsWithStats(core, connectivity=8)
    dots = []
    gd = cv2.dilate(green, np.ones((3, 3), np.uint8), iterations=max(1, int(round(t))))
    for i in range(1, n):
        x, y, w, h, a = st[i]
        if w > 6 * t + 6 or h > 6 * t + 6:
            continue
        cx, cy = cen[i]
        r = float(dt[lab == i].max())
        if r > 3.5 * t + 2:
            continue
        # must touch a wire
        yy, xx = int(round(cy)), int(round(cx))
        R = int(r + 2 * t + 2)
        win = gd[max(yy - R, 0):yy + R + 1, max(xx - R, 0):xx + R + 1]
        if win.sum() == 0:
            continue
        # roundness: area of red disc around
        dots.append((float(cx), float(cy), r))
    return dots


def remove_noconnect(green, t):
    """Remove EasyEDA no-connect 'X' flags (small green diagonal crosses)."""
    g = green.copy()
    n, lab, st, cen = cv2.connectedComponentsWithStats(green, connectivity=8)
    out = []
    for i in range(1, n):
        x, y, w, h, a = st[i]
        if w > 12 * t or h > 12 * t or w < 2 * t or h < 2 * t:
            continue
        if 0.6 < w / h < 1.6:
            sub = (lab[y:y + h, x:x + w] == i)
            # diagonal content: the two diagonals are well covered, centre row not full
            k = min(w, h)
            d1 = np.mean([sub[int(j * h / k), int(j * w / k)] or sub[min(int(j * h / k) + 1, h - 1), int(j * w / k)] for j in range(k)])
            d2 = np.mean([sub[int(j * h / k), w - 1 - int(j * w / k)] or sub[min(int(j * h / k) + 1, h - 1), w - 1 - int(j * w / k)] for j in range(k)])
            if d1 > 0.7 and d2 > 0.7 and a < 0.6 * w * h:
                g[lab == i] = 0
                out.append((float(cen[i][0]), float(cen[i][1])))
    return g, out


def fill_dots(green, dots, t):
    """Wires are partially hidden under junction dots: paint the wire through the dot
    in every axis direction where a green wire leaves the dot."""
    g = green.copy()
    H, W = g.shape
    hw = max(1, int(round(t / 2)))
    for (cx, cy, r) in dots:
        x0, y0 = int(round(cx)), int(round(cy))
        reach = int(r + 3 * t + 3)
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            hit = None
            for k in range(int(r * 0.5), reach):
                x, y = x0 + dx * k, y0 + dy * k
                if not (0 <= x < W and 0 <= y < H):
                    break
                # probe across the stroke width
                if dx:
                    win = green[max(y - hw - 1, 0):y + hw + 2, x]
                else:
                    win = green[y, max(x - hw - 1, 0):x + hw + 2]
                if win.sum() >= max(1, hw):
                    hit = k
                    break
            if hit is None:
                continue
            # find the actual centre line of the wire leaving the dot
            x, y = x0 + dx * (hit + 2), y0 + dy * (hit + 2)
            if dx:
                col = green[max(y - 3 * hw - 2, 0):y + 3 * hw + 3, min(max(x, 0), W - 1)]
                idx = np.where(col > 0)[0]
                yc = int(round(idx.mean())) + max(y - 3 * hw - 2, 0) if len(idx) else y0
                cv2.line(g, (x0, yc), (x0 + dx * (hit + 2), yc), 1, thickness=max(1, int(round(t))))
            else:
                row = green[min(max(y, 0), H - 1), max(x - 3 * hw - 2, 0):x + 3 * hw + 3]
                idx = np.where(row > 0)[0]
                xc = int(round(idx.mean())) + max(x - 3 * hw - 2, 0) if len(idx) else x0
                cv2.line(g, (xc, y0), (xc, y0 + dy * (hit + 2)), 1, thickness=max(1, int(round(t))))
    return g


def find_gray_dots(gray, t):
    n, lab, st, cen = cv2.connectedComponentsWithStats(gray, connectivity=8)
    out = []
    for i in range(1, n):
        x, y, w, h, a = st[i]
        if a >= 3 and w <= 4 * t + 4 and h <= 4 * t + 4 and 0.5 < w / max(h, 1) < 2.0 and a >= 0.3 * w * h:
            out.append((float(cen[i][0]), float(cen[i][1])))
    return out


def extract(img_rgb):
    P = Prims()
    M = masks(img_rgb)
    P.M = M
    H, W = img_rgb.shape[:2]
    P.H, P.W = H, W
    green = M['green']
    red = M['red']
    t = estimate_stroke(green) if green.sum() > 200 else estimate_stroke(red)
    P.t = t
    P.s = t / 1.5             # px per EasyEDA unit (approx)
    P.u = 10 * P.s            # one standard pin length
    fg = (M['mag'] > 60).astype(np.uint8)
    P.fg = fg
    # junction dots
    P.dots = find_junctions(red, green, t)
    # wires
    bridge = (M['lab'] > 0).astype(np.uint8)
    for (cx, cy, r) in P.dots:
        cv2.circle(bridge, (int(round(cx)), int(round(cy))), int(r + 2), 1, -1)
    green, P.noconn = remove_noconnect(green, t)
    green = fill_dots(green, P.dots, t)
    P.green = green
    textm = ((M['lab'] == 3) | (M['lab'] == 4) | (M['lab'] == 5) | (green > 0)).astype(np.uint8)
    segs = extract_segments(green, min_len=max(4, int(1.8 * t)), kind='w',
                            bridges=[(bridge, int(max(6, 0.75 * P.u))), (textm, int(4 * P.u))])
    # drop tiny wires that are just anti-aliasing debris
    P.wires = [s for s in segs if s.length >= max(4, 2.2 * t)]
    # residual diagonal wires
    P.diag = find_diagonals(green, P.wires, t)
    # red without dots
    red2 = red.copy()
    for (cx, cy, r) in P.dots:
        cv2.circle(red2, (int(round(cx)), int(round(cy))), int(np.ceil(r + 1.5)), 0, -1)
    P.red = red2
    P.gray_dots = find_gray_dots(M['gray'], t)
    return P


def find_diagonals(green, wires, t):
    g = green.copy()
    for s in wires:
        w = int(np.ceil(s.t / 2 + 1.5))
        if s.o == 'h':
            cv2.rectangle(g, (int(s.a) - 1, int(s.c - w)), (int(s.b) + 1, int(s.c + w)), 0, -1)
        else:
            cv2.rectangle(g, (int(s.c - w), int(s.a) - 1), (int(s.c + w), int(s.b) + 1), 0, -1)
    if g.sum() < 30:
        return []
    lines = cv2.HoughLinesP(g * 255, 1, np.pi / 180, threshold=int(8 * t), minLineLength=int(8 * t), maxLineGap=int(2 * t))
    out = []
    if lines is None:
        return out
    lines = np.asarray(lines).reshape(-1, 4)
    for l in lines:
        x1, y1, x2, y2 = map(float, l)
        ang = abs(np.degrees(np.arctan2(y2 - y1, x2 - x1))) % 180
        if min(ang, 180 - ang) < 8 or abs(ang - 90) < 8:
            continue
        out.append((x1, y1, x2, y2))
    # merge near-duplicates
    res = []
    for l in out:
        dup = False
        for r in res:
            if max(abs(l[0] - r[0]), abs(l[1] - r[1]), abs(l[2] - r[2]), abs(l[3] - r[3])) < 3 * t or \
               max(abs(l[0] - r[2]), abs(l[1] - r[3]), abs(l[2] - r[0]), abs(l[3] - r[1])) < 3 * t:
                dup = True
                break
        if not dup:
            res.append(l)
    return res
