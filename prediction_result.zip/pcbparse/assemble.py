"""Assemble primitives, symbols and texts into the competition JSON."""
import re
import math
import numpy as np
import cv2
from scipy.optimize import linear_sum_assignment

from .textclass import is_desig, prefix_type, desig_prefix, is_gnd_name, is_power_name, is_value
from .text import redecode
from .wiregraph import UF, decompose_edges

UPPER_DIGITS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'


def box_gap(a, b):
    """Gap between two boxes [x0,y0,x1,y1] (0 when overlapping)."""
    dx = max(a[0] - b[2], b[0] - a[2], 0)
    dy = max(a[1] - b[3], b[1] - a[3], 0)
    return math.hypot(dx, dy)


def tbox(it):
    return [it.x0, it.y0, it.x1, it.y1]


class Comp:
    def __init__(self, gid, bbox, pins):
        self.gids = [gid]
        self.bbox = list(bbox)
        self.pins = list(pins)
        self.type = None
        self.key = None
        self.name = None
        self.value = None
        self.desig_item = None
        self.label_item = None
        self.anon = False

    def __repr__(self):
        return f"Comp({self.key},{self.type},{self.bbox},{len(self.pins)}p)"


def group_body_info(S, P):
    """Per-group body geometry features."""
    glab = S['glab']
    info = {}
    for gid, g in S['groups'].items():
        x0, y0, x1, y1 = g['bbox']
        sub = (glab[y0:y1 + 1, x0:x1 + 1] == gid)
        info[gid] = {'mask': sub, 'off': (x0, y0)}
    return info


def rect_hole(gid, S, P):
    """Largest rectangular hole of a body group (IC body outline), image coords."""
    g = S['groups'][gid]
    if 'rect' in g:
        return g['rect']
    x0, y0, x1, y1 = g['bbox']
    m = (S['glab'][y0:y1 + 1, x0:x1 + 1] == gid).astype(np.uint8)
    cnts, hier = cv2.findContours(m, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
    best = None
    if hier is not None:
        for c, hh in zip(cnts, hier[0]):
            if hh[3] < 0:
                continue
            a = cv2.contourArea(c)
            bx, by, bw, bh = cv2.boundingRect(c)
            if bw < 0.9 * P.u or bh < 0.9 * P.u:
                continue
            if a < 0.8 * bw * bh:
                continue
            if best is None or a > best[0]:
                best = (a, [x0 + bx, y0 + by, x0 + bx + bw - 1, y0 + by + bh - 1])
    g['rect'] = best[1] if best else None
    return g['rect']


def clean_pins(S, P):
    u = P.u
    t = P.t
    markers = list(P.gray_dots) + list(getattr(P, 'noconn', []))
    for gid, g in S['groups'].items():
        x0, y0, x1, y1 = g['bbox']
        keep = []
        rect = None
        rect0 = rect_hole(gid, S, P)
        bx0, by0, bx1, by1 = rect0 if rect0 else (x0, y0, x1, y1)
        for pn in g['pins']:
            if pn.kind == 'free':
                tx, ty = pn.tip
                inside = (bx0 - 0.15 * u <= tx <= bx1 + 0.15 * u) and (by0 - 0.15 * u <= ty <= by1 + 0.15 * u)
                if inside or pn.length < 0.45 * u:
                    pn.group = -1
                    continue
                marked = any(math.hypot(mx - tx, my - ty) <= 1.8 * t + 2 for mx, my in markers)
                if not marked:
                    if rect is None:
                        rect = rect_hole(gid, S, P) or False
                    ok = False
                    if rect:
                        rx0, ry0, rx1, ry1 = rect
                        bx, by = pn.base
                        tol = 1.5 * t + 2
                        if pn.o == 'h' and ry0 - tol <= by <= ry1 + tol and (abs(bx - rx0) <= tol + t or abs(bx - rx1) <= tol + t):
                            ok = True
                        if pn.o == 'v' and rx0 - tol <= bx <= rx1 + tol and (abs(by - ry0) <= tol + t or abs(by - ry1) <= tol + t):
                            ok = True
                    if not ok:
                        pn.group = -1
                        continue
            keep.append(pn)
        g['pins'] = keep
    S['pins'] = [pn for pn in S['pins'] if pn.group != -1 and pn.group in S['groups']]


def shape_features(gid, S, P):
    """Simple shape descriptors of a body group."""
    g = S['groups'][gid]
    glab = S['glab']
    x0, y0, x1, y1 = g['bbox']
    m = (glab[y0:y1 + 1, x0:x1 + 1] == gid).astype(np.uint8)
    h, w = m.shape
    f = {'w': w, 'h': h, 'area': int(m.sum())}
    # closed contours (holes)
    cnts, hier = cv2.findContours(m.copy(), cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
    holes = []
    if hier is not None:
        for c, hh in zip(cnts, hier[0]):
            if hh[3] >= 0:
                a = cv2.contourArea(c)
                if a > (1.2 * P.t) ** 2:
                    bx, by, bw, bh = cv2.boundingRect(c)
                    rect = a / max(bw * bh, 1)
                    holes.append((a, bw, bh, rect))
    f['holes'] = holes
    f['fill'] = m.sum() / max(w * h, 1)
    return f


_P_CTX = [None]


def build(P, items, S, lines, uf, terms, lib=None, img_shape=None):
    global _LIB
    _LIB = lib
    _P_CTX[0] = P
    u, t = P.u, P.t
    H = P.H
    clean_pins(S, P)
    groups = S['groups']
    # ---------------------------------------------------------------- texts
    texts = [it for it in items if it.text]
    blue = [it for it in texts if it.color == 'blue']
    # ---------------------------------------------------------------- comps from groups
    comps = {}
    for gid, g in groups.items():
        if g['area'] < max(6, 0.6 * t * t):
            continue
        c = Comp(gid, g['bbox'], g['pins'])
        c.feat = shape_features(gid, S, P)
        comps[gid] = c
    # ---------------------------------------------------------------- power / labels (1-pin groups)
    used_text = set()

    def near_texts(c, maxd, pool):
        out = []
        for it in pool:
            d = box_gap(c.bbox, tbox(it))
            if d <= maxd:
                out.append((d, it))
        out.sort(key=lambda x: x[0])
        return out

    one_pin = [c for c in comps.values() if len(c.pins) == 1]
    for c in one_pin:
        c.flag = _is_flag(c, P)
    # net labels (flag shaped ports): text next to the flag
    for c in one_pin:
        if not c.flag:
            continue
        cand = [(d + _side_pen(c, it, u), it) for d, it in near_texts(c, 1.5 * u, blue) if it.id not in used_text and not is_value(it.text)]
        cand.sort(key=lambda x: x[0])
        if cand:
            d, it = cand[0]
            c.type = 'net_bidirection'
            c.label_item = it
            c.key = it.text
            c.value = it.text
            c.name = it.text
            used_text.add(it.id)
    # power / ground symbols with a name text
    for c in one_pin:
        if c.flag:
            continue
        cand = near_texts(c, 1.2 * u, blue)
        pw = [(d + _side_pen(c, it, u), it) for d, it in cand if is_power_name(it.text) and not is_desig(it.text) and it.id not in used_text]
        pw.sort(key=lambda x: x[0])
        if pw:
            d, it = pw[0]
            c.label_item = it
            used_text.add(it.id)
            c.type = 'gnd' if is_gnd_name(it.text) else 'v'
            c.value = 'GND' if (c.type == 'gnd' and len(it.text) == 3 and it.text != 'GND' and not it.text.endswith('GND')) else it.text
            c.anon = True
    # ---------------------------------------------------------------- designators
    desig_items = [it for it in blue if it.id not in used_text and _fix_desig(it)
                   and not (lib is not None and len(it.text) >= 5 and lib.match_name(it.text, 0.0))]
    cand_comps = [c for c in comps.values() if not c.anon and c.type is None]
    if desig_items and cand_comps:
        C = np.full((len(desig_items), len(cand_comps)), 1e6)
        onw = [_on_wire(it, P) for it in desig_items]
        rects = {id(c): rect_hole(c.gids[0], S, P) for c in cand_comps}
        for i, it in enumerate(desig_items):
            for j, c in enumerate(cand_comps):
                d = box_gap(c.bbox, tbox(it)) / u
                if d > 3.0:
                    continue
                pt = prefix_type(it.text)
                npins = len(c.pins)
                pen = 0.8 if onw[i] else 0.0
                big = rects[id(c)] is not None and min(c.feat['w'], c.feat['h']) >= 2.0 * u
                if pt == 'box' and not big and max(c.feat['w'], c.feat['h']) < 1.6 * u and npins <= 2:
                    pen += 0.8
                if pt in ('r', 'c', 'l', 'd', 'led') and big and npins >= 3:
                    pen += 1.5
                if big and npins >= 4 and pt not in ('box', 'switch', 'pin', None):
                    pen += 0.8
                if npins == 0:
                    pen += 1.5
                if pt in ('r', 'c', 'l') and npins > 2:
                    pen += 1.0
                if pt == 'box' and npins < 2 and c.feat['w'] < 1.5 * u and c.feat['h'] < 1.5 * u:
                    pen += 0.8
                if npins == 1 and pt in ('r', 'c', 'l', 'd', 'led'):
                    pen += 0.6
                C[i, j] = d + pen
        # dummy columns: leaving a text unassigned costs a fixed amount
        nT, nC = C.shape
        C = np.hstack([C, np.full((nT, nT), 2.6)])
        r, cidx = linear_sum_assignment(C)
        for i, j in zip(r, cidx):
            if j < nC and C[i, j] < 1e5:
                c = cand_comps[j]
                c.desig_item = desig_items[i]
                c.key = desig_items[i].text
                used_text.add(desig_items[i].id)
    # GND symbols without text: detect by shape (parallel bars)
    for c in one_pin:
        if c.type is None and c.key is None:
            ps = _power_shape(c, S, P)
            if ps:
                c.type = ps
                c.value = 'GND' if ps == 'gnd' else None
                c.anon = True
    # ---------------------------------------------------------------- net labels (1-pin, text along axis)
    for c in one_pin:
        if c.type is not None or c.key is not None:
            continue
        cand = [(d, it) for d, it in near_texts(c, 1.0 * u, blue) if it.id not in used_text and not is_value(it.text)]
        if cand:
            d, it = cand[0]
            c.type = 'net_bidirection'
            c.label_item = it
            c.key = it.text
            c.value = it.text
            c.name = it.text
            used_text.add(it.id)
    # ---------------------------------------------------------------- types
    for c in comps.values():
        if c.type is not None:
            continue
        if c.key:
            pt = prefix_type(c.key) or 'box'
            if pt == 'd' and _has_arrows(c, S, P):
                pt = 'led'
            if pt == 'box' and len(c.pins) == 1:
                pt = 'pin'
            npin = len(c.pins)
            if pt in ('mosfet', 'bjt'):
                pt = 'bjt' if _n_diagonals(c, S, P) >= 2 and not _has_gate_gap(c, S, P) else 'mosfet'
            elif pt == 'crystal_2pin':
                pt = {3: 'crystal_3pin', 4: 'crystal_4pin'}.get(npin, 'crystal_2pin')
            elif pt == 'box' and npin >= 3 and not rect_hole(c.gids[0], S, P) and _n_diagonals(c, S, P) >= 2:
                pt = {3: 'amp_3pin', 5: 'amp_5pin', 7: 'amp_7pin'}.get(npin, 'amp')
            c.type = pt
    # drop unassigned comps without pins/type
    final = [c for c in comps.values() if c.type is not None]
    # ---------------------------------------------------------------- values / names
    free_blue = [it for it in blue if it.id not in used_text]
    # values of passives: one-to-one assignment
    passives = [c for c in final if c.desig_item is not None and c.type in ('r', 'c', 'l', 'fuse', 'crystal_2pin')]
    vcands = [it for it in free_blue if not is_desig(it.text) and not is_power_name(it.text) and len(it.text) <= 14]
    if passives and vcands:
        C = np.full((len(passives), len(vcands)), 1e6)
        for i, c in enumerate(passives):
            for j, it in enumerate(vcands):
                d = min(box_gap(tbox(it), tbox(c.desig_item)), box_gap(tbox(it), c.bbox) + 0.3 * u) / u
                if not is_value(it.text):
                    d += 0.9
                if d <= 2.2:
                    C[i, j] = d
        r, cc = linear_sum_assignment(C)
        for i, j in zip(r, cc):
            if C[i, j] < 1e5:
                passives[i].value = _fix_value(vcands[j])
                used_text.add(vcands[j].id)
    for c in sorted(final, key=lambda c: (c.desig_item is None,)):
        if c.desig_item is None:
            continue
        if c.type in ('r', 'c', 'l', 'fuse', 'crystal_2pin'):
            pass
        else:
            res = pick_name(c, free_blue, used_text, u, lib if c.type in ("box", "switch") else None)
            if res:
                c.name = res[0]
                for it in res[1]:
                    used_text.add(it.id)
    # ---------------------------------------------------------------- LED arrows
    reassign_arrows(final, S, P)
    # ---------------------------------------------------------------- contact tips
    fix_contacts(final, P)
    standard_contact_tips(final, S, P)
    # ---------------------------------------------------------------- bbox refinement
    for c in final:
        if c.type in ('led', 'fuse', 'crystal_2pin', 'l', 'switch', 'buzzer', 'battary', 'other'):
            trim_stems(c, S, P)
        refine_bbox(c, P)
        if c.type in ('box', 'switch', 'pin'):
            r = rect_hole(c.gids[0], S, P)
            if r:
                h = P.t * 0.5
                c.bbox = [r[0] - h, r[1] - h, r[2] + h, r[3] + h]
    # ---------------------------------------------------------------- box pins
    for c in final:
        if c.type in ('box', 'switch'):
            assign_box_pins(c, items, P, S, lib)
    return final


LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
DIGITS = '0123456789'


def _fix_desig(it):
    s = it.text.replace(' ', '')
    if is_desig(s):
        it.text = s
        return True
    # constrained re-decode
    s2, conf = redecode(it, UPPER_DIGITS)
    if is_desig(s2) and conf > 0.5:
        it.text = s2
        return True
    # designator-shaped text (letters then digits) misread: decode letters/digits split
    if it.probs is not None and 2 <= len(s) <= 6 and s[:1].isalpha() and not it.vert or (it.probs is not None and it.vert and 2 <= len(s) <= 6):
        from .ocr import get_rec
        rec = get_rec()
        best = None
        for k in (1, 2, 3):
            t, c = rec.decode_split(it.probs, LETTERS, DIGITS, k)
            if is_desig(t) and len(t) == len(s) and (best is None or c > best[1]):
                best = (t, c)
        if best and best[1] > 0.4 and best[0][:1] == s[:1].upper():
            it.text = best[0]
            return True
    return False


def _fix_value(it):
    return it.text.replace(' ', '')


def _power_shape(c, S, P):
    """Classify a text-less one-pin symbol: 'gnd' (stacked bars), 'v' (single bar) or None."""
    pn = c.pins[0]
    f = c.feat
    x0, y0, x1, y1 = c.bbox
    rs = [s for s in S['rsegs'] if box_gap(c.bbox, [s.p0()[0], s.p0()[1], s.p1()[0], s.p1()[1]]) <= 1]
    tx, ty = pn.tip
    if pn.o == 'v' or (pn.o == 'z' and (ty < y0 or ty > y1)):
        bars = [s for s in rs if s.o == 'h' and s.length >= 0.25 * P.u]
        dist = lambda s: abs(s.c - ty)
    else:
        bars = [s for s in rs if s.o == 'v' and s.length >= 0.25 * P.u]
        dist = lambda s: abs(s.c - tx)
    rows = []
    for s in sorted(bars, key=dist):
        if rows and abs(dist(s) - rows[-1][0]) <= P.t + 1:
            rows[-1][1] = min(rows[-1][1], s.a)
            rows[-1][2] = max(rows[-1][2], s.b)
        else:
            rows.append([dist(s), s.a, s.b])
    if len(rows) >= 2:
        lens = [r[2] - r[1] for r in rows]
        if all(a >= b - P.t for a, b in zip(lens, lens[1:])) and lens[0] > lens[-1] + P.t:
            return 'gnd'
        return None
    if len(rows) == 1 and f['w'] * f['h'] < 2.5 * P.u * P.u:
        return 'v'
    return None


def _looks_gnd(c, S, P):
    return _power_shape(c, S, P) == 'gnd'


def _has_arrows(c, S, P):
    x0, y0, x1, y1 = c.bbox
    sub = (S['glab'][y0:y1 + 1, x0:x1 + 1] > 0)
    # arrows make the bbox clearly non-square relative to the triangle
    f = c.feat
    pins = c.pins
    if len(pins) >= 2:
        o = pins[0].o
        across = f['w'] if o == 'v' else f['h']
        along = f['h'] if o == 'v' else f['w']
        return across > 1.35 * along
    return False


# ------------------------------------------------------------------ box pin numbering
def assign_box_pins(c, items, P, S, lib):
    u = P.u
    t = P.t
    x0, y0, x1, y1 = c.bbox
    # zero-length pins on a box: infer orientation and base from the body outline
    for pn in c.pins:
        if pn.o == 'z':
            tx, ty = pn.tip
            dx = x0 - tx if tx < x0 else (tx - x1 if tx > x1 else 0)
            dy = y0 - ty if ty < y0 else (ty - y1 if ty > y1 else 0)
            if dx >= dy and dx > 0:
                pn.o = 'h'
                pn.base = (x0 if tx < x0 else x1, ty)
            elif dy > 0:
                pn.o = 'v'
                pn.base = (tx, y0 if ty < y0 else y1)
            else:
                continue
            d = np.array(pn.tip, float) - np.array(pn.base, float)
            n = np.linalg.norm(d)
            pn.dir = tuple(d / n) if n > 0 else (0.0, 0.0)
    pool = [it for it in items if it.text and box_gap(tbox(it), c.bbox) <= 1.5 * u]
    # --- pin numbers: one-to-one assignment of number-like texts to pin stubs
    nums = [it for it in pool if re.match(r'^[A-Z]{0,2}\d{1,3}[A-Z]?$', it.text) and it.color != 'blue'
            and not (x0 + 2 < it.cx < x1 - 2 and y0 + 2 < it.cy < y1 - 2)]
    pins = [pn for pn in c.pins if pn.o in ('h', 'v')]
    if nums and pins:
        # group pins by side; for each side try 'number before' / 'number after' the line
        sides = {}
        for pn in pins:
            key = (pn.o, 1 if (pn.dir[0] + pn.dir[1]) > 0 else -1)
            sides.setdefault(key, []).append(pn)
        used_nums = set()
        for key, sp in sides.items():
            best = None
            for hyp in (-1, 1):
                C = np.full((len(sp), len(nums)), 1e6)
                for i, pn in enumerate(sp):
                    tx, ty = pn.tip
                    bx, by = pn.base
                    for j, it in enumerate(nums):
                        if j in used_nums:
                            continue
                        if pn.o == 'h':
                            lo, hi = min(tx, bx), max(tx, bx)
                            along = max(lo - it.cx, 0, it.cx - hi)
                            gap = (by - it.y1) if hyp < 0 else (it.y0 - by)
                        else:
                            lo, hi = min(ty, by), max(ty, by)
                            along = max(lo - it.cy, 0, it.cy - hi)
                            gap = (bx - it.x1) if hyp < 0 else (it.x0 - bx)
                        if gap < -0.2 * u or gap > 0.5 * u or along > 0.5 * u:
                            continue
                        C[i, j] = abs(gap - 0.1 * u) + 0.5 * along
                r, cc = linear_sum_assignment(C)
                pairs = [(i, j) for i, j in zip(r, cc) if C[i, j] < 1e5]
                cost = sum(C[i, j] for i, j in pairs) / u
                score = len(pairs) - 0.1 * cost
                if best is None or score > best[0]:
                    best = (score, pairs)
            for i, j in best[1]:
                sp[i].num = nums[j].text
                used_nums.add(j)
    # --- pin names: text inside the body next to the pin base
    names = [it for it in pool if (x0 - 2 <= it.cx <= x1 + 2) and (y0 - 2 <= it.cy <= y1 + 2)]
    if names and pins:
        C = np.full((len(pins), len(names)), 1e6)
        for i, pn in enumerate(pins):
            bx, by = pn.base
            for j, it in enumerate(names):
                cx, cy = it.cx, it.cy
                if pn.o == 'h':
                    if abs(cy - by) > 0.45 * u:
                        continue
                    edge = it.x0 if bx <= (x0 + x1) / 2 else it.x1
                    d = abs(edge - bx) / u + abs(cy - by) / u
                    if it.vert:
                        d += 1.0
                else:
                    if abs(cx - bx) > 0.45 * u:
                        continue
                    edge = it.y0 if by <= (y0 + y1) / 2 else it.y1
                    d = abs(edge - by) / u + abs(cx - bx) / u
                    if not it.vert:
                        d += 0.5
                if d > 2.5:
                    continue
                C[i, j] = d
        r, cc = linear_sum_assignment(C)
        for i, j in zip(r, cc):
            if C[i, j] < 1e5:
                pins[i].name = names[j].text
    if lib is not None:
        lib.correct(c)


def trim_stems(c, S, P):
    """Remove leftover straight pin-line portions at both ends of a 2-pin body along its axis."""
    if len(c.pins) != 2:
        return
    a, b = c.pins
    horiz = abs(a.tip[0] - b.tip[0]) > abs(a.tip[1] - b.tip[1])
    x0, y0, x1, y1 = [int(round(v)) for v in c.bbox]
    if x1 <= x0 or y1 <= y0:
        return
    m = np.isin(S['glab'][y0:y1 + 1, x0:x1 + 1], c.gids)
    if m.sum() == 0:
        return
    prof = m.any(0) if False else None
    # perpendicular span of every slice along the axis
    if horiz:
        span = np.array([(np.ptp(np.nonzero(m[:, i])[0]) + 1) if m[:, i].any() else 0 for i in range(m.shape[1])])
    else:
        span = np.array([(np.ptp(np.nonzero(m[i, :])[0]) + 1) if m[i, :].any() else 0 for i in range(m.shape[0])])
    thin = span <= 1.6 * P.t + 1
    lo = 0
    while lo < len(span) and thin[lo]:
        lo += 1
    hi = len(span) - 1
    while hi > lo and thin[hi]:
        hi -= 1
    if hi - lo < 0.3 * P.u:
        return
    if horiz:
        c.bbox[0], c.bbox[2] = x0 + lo, x0 + hi
    else:
        c.bbox[1], c.bbox[3] = y0 + lo, y0 + hi


def refine_bbox(c, P):
    u = P.u
    if c.type in ('gnd', 'v') and len(c.pins) == 1:
        tx, ty = c.pins[0].tip
        x0, y0, x1, y1 = c.bbox
        if c.type == 'v':
            ext = 0.45 * u      # power port: the bbox covers part of the stub
            if tx < x0:
                c.bbox[0] = max(tx, x0 - ext)
            elif tx > x1:
                c.bbox[2] = min(tx, x1 + ext)
            elif ty < y0:
                c.bbox[1] = max(ty, y0 - ext)
            elif ty > y1:
                c.bbox[3] = min(ty, y1 + ext)
        else:
            ext = 0.3 * u       # ground: the bbox has a margin below the last bar
            if tx < x0:
                c.bbox[2] = x1 + ext
            elif tx > x1:
                c.bbox[0] = x0 - ext
            elif ty < y0:
                c.bbox[3] = y1 + ext
            elif ty > y1:
                c.bbox[1] = y0 - ext
    if c.type in ('r', 'c', 'd') and len(c.pins) == 2:
        a, b = c.pins
        if a.o == b.o == 'h' or (abs(a.tip[0] - b.tip[0]) > abs(a.tip[1] - b.tip[1]) and a.o != 'v'):
            lo, hi = sorted([a.tip[0], b.tip[0]])
            if hi - lo > 2.2 * u:
                c.bbox[0], c.bbox[2] = lo + u, hi - u
        else:
            lo, hi = sorted([a.tip[1], b.tip[1]])
            if hi - lo > 2.2 * u:
                c.bbox[1], c.bbox[3] = lo + u, hi - u


def pick_name(c, pool, used, u, lib):
    """Choose the part-name text of a component (IC name / part number)."""
    rect = c.bbox
    cands = []
    free = [it for it in pool if it.id not in used and
            (not is_desig(it.text) or (lib is not None and len(it.text) >= 5 and lib.match_name(it.text, 0.0)))]
    # single items and horizontally adjacent pairs (names with spaces)
    for it in free:
        cands.append(([it], it.text))
    for a in free:
        for b in free:
            if a is b or a.vert or b.vert:
                continue
            ch = max(a.h, b.h)
            if abs(a.cy - b.cy) <= 0.35 * ch and 0 <= b.x0 - a.x1 <= 1.3 * ch:
                cands.append(([a, b], a.text + ' ' + b.text))
    best = None
    for its, txt in cands:
        x0 = min(i.x0 for i in its); y0 = min(i.y0 for i in its)
        x1 = max(i.x1 for i in its); y1 = max(i.y1 for i in its)
        bb = [x0, y0, x1, y1]
        # inside the body (pin names) -> skip unless it is a library name
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        inside = rect[0] + 2 < cx < rect[2] - 2 and rect[1] + 2 < cy < rect[3] - 2
        d = box_gap(rect, bb)
        if c.desig_item is not None:
            d = min(d, box_gap(tbox(c.desig_item), bb) * 0.8)
        if d > 3.0 * u:
            continue
        sc = d / u
        libname = lib.match_name(txt, 0.12) if (lib is not None and len(txt) >= 4 and not is_power_name(txt)) else None
        if libname:
            sc -= 2.0 + 0.05 * len(txt)
        elif inside:
            continue
        if is_power_name(txt) and not libname:
            sc += 1.5
        if not libname and any(_on_wire(i, _P_CTX[0]) for i in its):
            sc += 1.5
        if c.desig_item is not None:
            dg = c.desig_item
            if abs(x0 - dg.x0) <= 0.3 * u or abs(x1 - dg.x1) <= 0.3 * u:
                sc -= 0.4                     # left/right aligned with the designator
            elif abs((y0 + y1) / 2 - dg.cy) < 0.5 * dg.h:
                sc += 0.4                     # same row but not aligned: usually another label
        if is_value(txt) and not libname:
            sc += 0.8
        if len(its) == 2 and not libname:
            sc += 1.0
        if best is None or sc < best[0]:
            best = (sc, libname or txt, its)
    if best is None:
        return None
    return best[1], best[2]


def _is_flag(c, P):
    """Net-label flag: an elongated closed polygon with the pin on a short side."""
    f = c.feat
    if not f['holes']:
        return False
    w, h = f['w'], f['h']
    big = max(f['holes'], key=lambda x: x[0])
    a, bw, bh, rect = big
    if a < 0.2 * w * h:
        return False
    if rect > 0.88:
        return False
    if max(w, h) < 1.6 * min(w, h):
        return False
    pn = c.pins[0]
    horiz = w > h
    tx, ty = pn.tip
    x0, y0, x1, y1 = c.bbox
    if horiz:
        return abs(ty - (y0 + y1) / 2) <= 0.3 * h + 2 and (tx <= x0 + 0.25 * w or tx >= x1 - 0.25 * w)
    return abs(tx - (x0 + x1) / 2) <= 0.3 * w + 2 and (ty <= y0 + 0.25 * h or ty >= y1 - 0.25 * h)


def _side_pen(c, it, u):
    """Penalty when a label text lies on the pin side of a one-pin symbol."""
    pn = c.pins[0]
    x0, y0, x1, y1 = c.bbox
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    vx, vy = pn.tip[0] - cx, pn.tip[1] - cy
    tx, ty = it.cx - cx, it.cy - cy
    n = (vx * vx + vy * vy) ** 0.5
    if n < 1e-6:
        return 0.0
    proj = (tx * vx + ty * vy) / n
    return 0.6 * u if proj > 0.3 * u else 0.0


ONE_PIN_TYPES = ('gnd', 'v', 'net_bidirection', 'net_input', 'net_output', 'net_short')


def fix_contacts(comps, P):
    """Place the contact point of two directly touching pins using pin-length
    conventions: power/net symbols have zero-length pins, R/IC pins are 1u long."""
    u = P.u
    owner = {}
    for c in comps:
        for pn in c.pins:
            owner[id(pn)] = c
    done = set()
    for c in comps:
        for pa in c.pins:
            pb = getattr(pa, 'mate', None)
            if pb is None or id(pa) in done or id(pb) not in owner:
                continue
            done.add(id(pa)); done.add(id(pb))
            ca, cb = c, owner[id(pb)]
            if pa.seg is None and pb.seg is None:
                continue
            # link geometry
            if pa.seg is not None and pb.seg is not None and pa.seg is pb.seg:
                A, B = pa.base, pb.base
            else:
                # one side is a zero pin sitting on the other body
                continue
            dx, dy = B[0] - A[0], B[1] - A[1]
            L = (dx * dx + dy * dy) ** 0.5
            if L < 1e-6:
                continue
            ux, uy = dx / L, dy / L
            tip = None
            NETS = ('net_bidirection', 'net_input', 'net_output', 'net_short')
            if ca.type in NETS and cb.type not in NETS:
                tip = A
            elif cb.type in NETS and ca.type not in NETS:
                tip = B
            elif 1.6 * u <= L <= 2.4 * u:
                tip = ((A[0] + B[0]) / 2, (A[1] + B[1]) / 2)
            elif ca.type in ('r', 'box') and cb.type not in ('r', 'box') and L >= 0.8 * u:
                d = min(u, L)
                tip = (A[0] + ux * d, A[1] + uy * d)
            elif cb.type in ('r', 'box') and ca.type not in ('r', 'box') and L >= 0.8 * u:
                d = min(u, L)
                tip = (B[0] - ux * d, B[1] - uy * d)
            if tip is not None:
                pa.tip = tuple(tip)
                pb.tip = tuple(tip)


def _body_mask(c, S):
    x0, y0, x1, y1 = [int(round(v)) for v in S['groups'][c.gids[0]]['bbox']]
    return (S['glab'][y0:y1 + 1, x0:x1 + 1] == c.gids[0]).astype(np.uint8)


def _n_diagonals(c, S, P):
    """Number of distinct diagonal strokes (>= 0.45u) in the body."""
    m = _body_mask(c, S)
    if m.sum() < 10:
        return 0
    L = cv2.HoughLinesP(m * 255, 1, np.pi / 90, threshold=max(6, int(0.3 * P.u)),
                        minLineLength=max(6, int(0.45 * P.u)), maxLineGap=2)
    if L is None:
        return 0
    L = np.asarray(L).reshape(-1, 4)
    angs = []
    for x1, y1, x2, y2 in L:
        a = np.degrees(np.arctan2(y2 - y1, x2 - x1)) % 180
        if 15 < a < 75 or 105 < a < 165:
            if not any(abs(a - b) < 10 for b in angs):
                angs.append(a)
    return len(angs)


def _has_gate_gap(c, S, P):
    """MOSFET gate: two parallel straight strokes separated by a small gap."""
    m = _body_mask(c, S)
    h, w = m.shape
    for arr in (m, m.T):
        cols = arr.sum(0)
        long_cols = np.where(cols >= 0.8 * P.u)[0]
        if len(long_cols) >= 2:
            groups = np.split(long_cols, np.where(np.diff(long_cols) > 1)[0] + 1)
            if len(groups) >= 2:
                centers = [g.mean() for g in groups]
                for a, b in zip(centers, centers[1:]):
                    if 0.15 * P.u <= b - a <= 0.5 * P.u:
                        return True
    return False


def _piece_bbox_map(pieces):
    ys, xs = np.nonzero(pieces)
    labs = pieces[ys, xs]
    n = int(pieces.max()) + 1
    bb = np.zeros((n, 4), np.int64)
    bb[:, 0] = 1 << 30; bb[:, 1] = 1 << 30; bb[:, 2] = -1; bb[:, 3] = -1
    np.minimum.at(bb[:, 0], labs, xs); np.minimum.at(bb[:, 1], labs, ys)
    np.maximum.at(bb[:, 2], labs, xs); np.maximum.at(bb[:, 3], labs, ys)
    area = np.bincount(labs, minlength=n)
    return bb, area


def reassign_arrows(comps, S, P):
    """Small arrow pieces belong to the nearest LED / photo device, not to whatever
    anchored piece happened to be closest (dense layouts)."""
    leds = [c for c in comps if c.type in ('led', 'opt')]
    if not leds or 'pieces' not in S:
        return
    u = P.u
    pieces = S['pieces']
    glab = S['glab']
    bb, area = _piece_bbox_map(pieces)
    gid_of = {}
    for c in comps:
        for g in c.gids:
            gid_of[g] = c
    pin_pieces = set()
    for c in comps:
        for pn in c.pins:
            x, y = int(round(pn.base[0])), int(round(pn.base[1]))
            win = pieces[max(y - 3, 0):y + 4, max(x - 3, 0):x + 4]
            pin_pieces.update(int(v) for v in np.unique(win) if v > 0)
    moved = {}
    for pc in range(1, len(area)):
        if area[pc] == 0 or pc in pin_pieces:
            continue
        w = bb[pc, 2] - bb[pc, 0] + 1
        h = bb[pc, 3] - bb[pc, 1] + 1
        if max(w, h) > 1.5 * u or max(w, h) < 0.25 * u:
            continue
        if area[pc] > 0.45 * w * h:
            continue
        # owner group of this piece
        y0, x0 = bb[pc, 1], bb[pc, 0]
        sub = (pieces[bb[pc, 1]:bb[pc, 3] + 1, bb[pc, 0]:bb[pc, 2] + 1] == pc)
        lab_vals = glab[bb[pc, 1]:bb[pc, 3] + 1, bb[pc, 0]:bb[pc, 2] + 1][sub]
        owner_g = int(np.bincount(lab_vals).argmax()) if lab_vals.size else 0
        owner = gid_of.get(owner_g)
        if owner is not None and owner.type in ('led', 'opt'):
            continue
        pbox = [bb[pc, 0], bb[pc, 1], bb[pc, 2], bb[pc, 3]]
        best = None
        for c in leds:
            body = c.body_bbox if hasattr(c, 'body_bbox') else c.bbox
            d = box_gap(body, pbox)
            if d <= 1.0 * u and (best is None or d < best[0]):
                best = (d, c)
        if best is None:
            continue
        if owner is not None and box_gap(owner.bbox, pbox) + 0.05 * u < best[0] and owner.type not in ('r', 'c', 'l', 'box'):
            continue
        moved.setdefault(id(best[1]), (best[1], []))[1].append(pbox)
        if owner is not None:
            owner.removed = getattr(owner, 'removed', []) + [pc]
    for c, boxes in moved.values():
        for b in boxes:
            c.bbox = [min(c.bbox[0], b[0]), min(c.bbox[1], b[1]), max(c.bbox[2], b[2]), max(c.bbox[3], b[3])]
    # owners losing pieces: recompute their bbox from the remaining pixels
    for c in comps:
        rem = getattr(c, 'removed', None)
        if not rem:
            continue
        g = c.gids[0]
        x0, y0, x1, y1 = [int(v) for v in S['groups'][g]['bbox']]
        m = (glab[y0:y1 + 1, x0:x1 + 1] == g) & ~np.isin(pieces[y0:y1 + 1, x0:x1 + 1], rem)
        ys, xs = np.nonzero(m)
        if len(ys):
            c.bbox = [x0 + xs.min(), y0 + ys.min(), x0 + xs.max(), y0 + ys.max()]


def _on_wire(it, P):
    """Plain net-name text sits on (or right above) a wire."""
    t = P.t
    for w in P.wires:
        if it.vert:
            if w.o != 'v':
                continue
            if it.x0 - 2 * t <= w.c <= it.x1 + 2 * t and min(w.b, it.y1) - max(w.a, it.y0) >= 0.5 * it.h:
                return True
        else:
            if w.o != 'h':
                continue
            if it.y0 - 2 * t <= w.c <= it.y1 + 2 * t and min(w.b, it.x1) - max(w.a, it.x0) >= 0.5 * it.w:
                return True
    return False


def _body_center_along(c, S, P, horiz):
    """Centre of the symbol body along the pin axis, ignoring straight stems."""
    x0, y0, x1, y1 = [int(round(v)) for v in S['groups'][c.gids[0]]['bbox']]
    m = np.isin(S['glab'][y0:y1 + 1, x0:x1 + 1], c.gids)
    if not m.any():
        return None
    if horiz:
        span = np.array([(np.ptp(np.nonzero(m[:, i])[0]) + 1) if m[:, i].any() else 0 for i in range(m.shape[1])])
    else:
        span = np.array([(np.ptp(np.nonzero(m[i, :])[0]) + 1) if m[i, :].any() else 0 for i in range(m.shape[0])])
    wide = np.nonzero(span > 1.6 * P.t + 1)[0]
    if len(wide) == 0:
        return None
    return (x0 if horiz else y0) + (wide[0] + wide[-1]) / 2.0


def standard_contact_tips(comps, S, P):
    """Capacitors / resistors touching another symbol directly: the touching point is
    at the standard pin length from the body (C: centre +- 2u, R: centre +- 2u)."""
    u = P.u
    for c in comps:
        if c.type not in ('c',) or len(c.pins) != 2:
            continue
        a, b = c.pins
        horiz = abs(a.tip[0] - b.tip[0]) > abs(a.tip[1] - b.tip[1])
        cen = _body_center_along(c, S, P, horiz)
        if cen is None:
            continue
        for pn in (a, b):
            if pn.kind not in ('contact', 'zero') or pn.term is not None:
                continue
            k = 0 if horiz else 1
            side = 1 if pn.tip[k] > cen else -1
            new = cen + side * 2 * u
            if abs(new - pn.tip[k]) > 0.6 * u:
                continue
            tip = list(pn.tip)
            tip[k] = new
            pn.tip = tuple(tip)
            m = getattr(pn, 'mate', None)
            if m is not None:
                mt = list(m.tip)
                mt[k] = new
                m.tip = tuple(mt)
