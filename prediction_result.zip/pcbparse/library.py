"""IC library (BoxICLibrary.json / cpntLibrary) for name & pin correction."""
import json
import os
import re
from collections import defaultdict


def lev(a, b):
    if a == b:
        return 0
    if not a:
        return len(b)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


CONFUSE = str.maketrans({'O': '0', 'o': '0', 'I': '1', 'l': '1', '|': '1', 'S': '5', 'Z': '2', 'B': '8', 'G': '6', 'D': '0', 'Q': '0'})


def canon(s):
    return re.sub(r'[\s_\-]', '', (s or '').upper()).translate(CONFUSE)


class Library:
    def __init__(self, paths):
        self.parts = {}
        for p in paths:
            if not p or not os.path.exists(p):
                continue
            try:
                d = json.load(open(p, encoding='utf-8'))
            except Exception:
                continue
            for name, rec in d.items():
                pins = rec.get('pins', []) if isinstance(rec, dict) else []
                m = self.parts.setdefault(name, defaultdict(list))
                for pn in pins:
                    num = str(pn.get('number', '')).strip()
                    nm = str(pn.get('name', '')).strip()
                    if num and nm and nm not in m[num]:
                        m[num].append(nm)
        self.canon_index = defaultdict(list)
        for name in self.parts:
            self.canon_index[canon(name)].append(name)
        self.names = list(self.parts)

    def match_name(self, text, max_rel=0.2):
        if not text:
            return None
        if text in self.parts:
            return text
        ct = canon(text)
        if ct in self.canon_index:
            return self.canon_index[ct][0]
        best = None
        for name in self.names:
            cn = canon(name)
            if abs(len(cn) - len(ct)) > max(2, int(max_rel * len(ct)) + 1):
                continue
            d = lev(ct, cn)
            rel = d / max(len(cn), 1)
            if rel <= max_rel and (best is None or rel < best[0]):
                best = (rel, name)
        return best[1] if best else None

    def correct(self, comp):
        if not comp.name or len(comp.name) < 4:
            return
        name = self.match_name(comp.name) if comp.name else None
        if name is None:
            return
        if len(canon(comp.name)) >= 4:
            comp.name = name
        pm = self.parts[name]
        if not pm:
            return
        numbers = set(pm)
        # pin numbers: fix via names when the number is missing or unknown
        name_to_nums = defaultdict(set)
        for num, nms in pm.items():
            for nm in nms:
                name_to_nums[nm].add(num)
        used = set(pn.num for pn in comp.pins if pn.num in numbers)
        for pn in comp.pins:
            if pn.num in numbers:
                continue
            if pn.name and pn.name in name_to_nums:
                cands = [n for n in name_to_nums[pn.name] if n not in used]
                if len(cands) == 1:
                    pn.num = cands[0]
                    used.add(pn.num)
        for pn in comp.pins:
            if pn.num in pm:
                names = pm[pn.num]
                if pn.name in names:
                    continue
                if pn.name is None:
                    pn.name = names[0]
                    continue
                # choose closest library name if OCR looks like a misread
                best = min(names, key=lambda nm: lev(canon(nm), canon(pn.name)))
                d = lev(canon(best), canon(pn.name))
                if d <= max(1, len(best) // 3):
                    pn.name = best
