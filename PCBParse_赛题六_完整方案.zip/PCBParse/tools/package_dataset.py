#!/usr/bin/env python3
"""Package a validated dataset for the data-contribution bonus.

Usage:
    python tools/package_dataset.py dataset/ --team ABC123 [--desc my_description.docx]

Produces team_<team>_result_dataset.zip containing
    dataset/<case_id>.png, dataset/<case_id>.json
    dataset_description.docx  (generated if --desc is not given)
"""
import os
import sys
import zipfile
import json
import argparse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from validate_dataset import check_case, CASE_RE  # noqa: E402


def make_description(path, team, n_cases, stats):
    try:
        import docx
    except ImportError:
        raise SystemExit('python-docx is required to generate the description (pip install python-docx), '
                         'or pass --desc with your own document')
    d = docx.Document()
    d.add_heading('数据说明文档', 0)
    d.add_paragraph(f'队伍标识：{team}')
    d.add_heading('1. 数据来源', 1)
    d.add_paragraph('原理图图片来自嘉立创开源硬件平台（oshwhub.com）等公开开源项目，使用嘉立创 EDA 导出的彩色原理图截图，'
                    '已去除图框与标题栏；与赛题提供的 200 个训练案例不重复。')
    d.add_heading('2. 数量', 1)
    d.add_paragraph(f'共 {n_cases} 个案例，每个案例包含同名 PNG 原图与 JSON 标注（与赛题输出格式一致）。')
    d.add_heading('3. 许可与授权', 1)
    d.add_paragraph('所用原理图均来自以开源许可证公开的项目（如 CC BY-SA / GPL / MIT 等），仅用于学术研究与竞赛数据集建设，'
                    '并同意贡献至 PCBnet 开源数据集。')
    d.add_heading('4. 坐标系声明', 1)
    d.add_paragraph('所有绝对坐标为图内像素坐标，以图片左下角为原点，x 轴向右增大，y 轴向上增大，'
                    '一律为整数像素（粒度 1 像素）；元件框 bbox 为 [x1, y1, x2, y2]，(x1, y1) 为左下角，(x2, y2) 为右上角。'
                    '不使用相对坐标。')
    d.add_heading('5. 标注方法与使用说明', 1)
    d.add_paragraph('采用“自动预标注 + 人工逐张校对”：先用本队解析程序生成初始标注，再用浏览器校对工具逐个核对元件位号、类型、'
                    '型号/取值、引脚号与引脚名、引脚端点坐标、网络连接（hyperGraph）与导线线段，最后用自动检查脚本验证 Schema、'
                    '引用一致性与有效性（≥1 个 IC、≥5 个有效元件、≥5 个有效网络、IC 有效引脚数达标）。'
                    'components 以位号为键；电源/地等无位号元件以 ∅n 编号；网络标签以标签文字为键，重名加 _2、_3 后缀；'
                    'pins 键为 pin_<引脚号>；nets 中 edges 每条线段恰好两个端点，折线按拐点拆分。')
    d.add_heading('6. 统计', 1)
    for k, v in stats.items():
        d.add_paragraph(f'{k}: {v}')
    d.save(path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('folder')
    ap.add_argument('--team', required=True)
    ap.add_argument('--desc', default=None)
    ap.add_argument('--out', default='.')
    a = ap.parse_args()
    if not CASE_RE.match(a.team):
        raise SystemExit('team id must use ASCII letters, digits and "_" only')
    cases = sorted(os.path.splitext(f)[0] for f in os.listdir(a.folder) if f.lower().endswith('.json'))
    good = []
    tot_c = tot_n = 0
    for cid in cases:
        png = os.path.join(a.folder, cid + '.png')
        if not os.path.exists(png):
            print('skip (no png):', cid)
            continue
        J = json.load(open(os.path.join(a.folder, cid + '.json'), encoding='utf-8'))
        err, warn, st = check_case(cid, J)
        if err:
            print('skip (invalid):', cid, err[:3])
            continue
        good.append(cid)
        tot_c += st['components']
        tot_n += st['nets']
    if len(good) < 20:
        print(f'WARNING: only {len(good)} valid cases (>= 20 required)')
    desc = a.desc
    if desc is None:
        desc = os.path.join(a.out, 'dataset_description.docx')
        make_description(desc, a.team, len(good), {'有效案例数': len(good), '元件总数': tot_c, '有效网络总数': tot_n})
    zpath = os.path.join(a.out, f'team_{a.team}_result_dataset.zip')
    with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED) as z:
        for cid in good:
            z.write(os.path.join(a.folder, cid + '.png'), f'dataset/{cid}.png')
            z.write(os.path.join(a.folder, cid + '.json'), f'dataset/{cid}.json')
        ext = os.path.splitext(desc)[1].lower()
        z.write(desc, 'dataset_description' + ext)
    print('written', zpath, 'with', len(good), 'cases')


if __name__ == '__main__':
    main()
